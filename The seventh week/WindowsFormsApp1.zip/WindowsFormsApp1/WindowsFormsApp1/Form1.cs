﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private Graphics graphics;
        void drawCayleyTree(Pen p,int n, double x0, double y0, double leng, double th,double th1,double th2,double per1,double per2)
        {
            if (n == 0) return;
            double x1 = x0 + leng * Math.Cos(th);
            double y1 = y0 + leng * Math.Sin(th);
            graphics.DrawLine(p, (int)x0, (int)y0, (int)x1, (int)y1);
            drawCayleyTree(p,n - 1, x1, y1, per1 * leng, th + th1,th1,th2,per1,per2);
            drawCayleyTree(p,n - 1, x1, y1, per2 * leng, th - th2, th1, th2, per1, per2);
        }

        private void btnDraw_Click(object sender, EventArgs e)
        {
            if (graphics == null)
                graphics = drawPanel.CreateGraphics();
            graphics.Clear(Color.White);
            try
            {
                int n = Int32.Parse(txtDeepth.Text);
                double leng = Double.Parse(txtMainTrunkLength.Text);
                double th1 = Double.Parse(txtRightTrunkAngle.Text);
                double th2 = Double.Parse(txtLeftTrunkAngle.Text);
                double per1 = Double.Parse(txtRightTrunkScale.Text);
                double per2 = Double.Parse(txtLeftTrunkScale.Text);
                Pen p = new Pen(Color.White);
                switch (cmbTreeColor.SelectedItem)
                {
                    case "红色":
                        p.Color = Color.Red;
                        break;
                    case "橙色":
                        p.Color = Color.Orange;
                        break;
                    case "黄色":
                        p.Color = Color.Yellow;
                        break;
                    case "绿色":
                        p.Color = Color.Green;
                        break;
                    case "蓝色":
                        p.Color = Color.Blue;
                        break;
                    case "靛色":
                        p.Color = Color.Indigo;
                        break;
                    case "紫色":
                        p.Color = Color.Violet;
                        break;

                }
                lblArgumentsIsLegalShow.Text = "Y";
                drawCayleyTree(p, n, 200, 500, leng, -Math.PI / 2, th1, th2, per1, per2);
            }
            catch
            {
                lblArgumentsIsLegalShow.Text = "N";
            }

        }
    }
}
