﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDraw = new System.Windows.Forms.Button();
            this.lblDeepth = new System.Windows.Forms.Label();
            this.lblMainTrunkLength = new System.Windows.Forms.Label();
            this.lblRightTrunkScale = new System.Windows.Forms.Label();
            this.lblLeftTrunkScale = new System.Windows.Forms.Label();
            this.lblRightTrunkAngle = new System.Windows.Forms.Label();
            this.lblLeftTrunkAngle = new System.Windows.Forms.Label();
            this.txtDeepth = new System.Windows.Forms.TextBox();
            this.txtMainTrunkLength = new System.Windows.Forms.TextBox();
            this.txtRightTrunkScale = new System.Windows.Forms.TextBox();
            this.txtLeftTrunkScale = new System.Windows.Forms.TextBox();
            this.txtRightTrunkAngle = new System.Windows.Forms.TextBox();
            this.txtLeftTrunkAngle = new System.Windows.Forms.TextBox();
            this.cmbTreeColor = new System.Windows.Forms.ComboBox();
            this.lblTreeColor = new System.Windows.Forms.Label();
            this.drawPanel = new System.Windows.Forms.Panel();
            this.lblArgumentsIsLegal = new System.Windows.Forms.Label();
            this.lblArgumentsIsLegalShow = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnDraw
            // 
            this.btnDraw.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDraw.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDraw.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnDraw.Location = new System.Drawing.Point(845, 402);
            this.btnDraw.Name = "btnDraw";
            this.btnDraw.Size = new System.Drawing.Size(138, 35);
            this.btnDraw.TabIndex = 0;
            this.btnDraw.Text = "DrawCayleyTree";
            this.btnDraw.UseVisualStyleBackColor = false;
            this.btnDraw.Click += new System.EventHandler(this.btnDraw_Click);
            // 
            // lblDeepth
            // 
            this.lblDeepth.AutoSize = true;
            this.lblDeepth.Font = new System.Drawing.Font("楷体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblDeepth.Location = new System.Drawing.Point(788, 41);
            this.lblDeepth.Name = "lblDeepth";
            this.lblDeepth.Size = new System.Drawing.Size(89, 19);
            this.lblDeepth.TabIndex = 1;
            this.lblDeepth.Text = "递归深度";
            // 
            // lblMainTrunkLength
            // 
            this.lblMainTrunkLength.AutoSize = true;
            this.lblMainTrunkLength.Font = new System.Drawing.Font("楷体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblMainTrunkLength.Location = new System.Drawing.Point(788, 83);
            this.lblMainTrunkLength.Name = "lblMainTrunkLength";
            this.lblMainTrunkLength.Size = new System.Drawing.Size(89, 19);
            this.lblMainTrunkLength.TabIndex = 2;
            this.lblMainTrunkLength.Text = "主干长度";
            // 
            // lblRightTrunkScale
            // 
            this.lblRightTrunkScale.AutoSize = true;
            this.lblRightTrunkScale.Font = new System.Drawing.Font("楷体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblRightTrunkScale.Location = new System.Drawing.Point(748, 125);
            this.lblRightTrunkScale.Name = "lblRightTrunkScale";
            this.lblRightTrunkScale.Size = new System.Drawing.Size(129, 19);
            this.lblRightTrunkScale.TabIndex = 3;
            this.lblRightTrunkScale.Text = "右分支长度比";
            // 
            // lblLeftTrunkScale
            // 
            this.lblLeftTrunkScale.AutoSize = true;
            this.lblLeftTrunkScale.Font = new System.Drawing.Font("楷体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblLeftTrunkScale.Location = new System.Drawing.Point(748, 164);
            this.lblLeftTrunkScale.Name = "lblLeftTrunkScale";
            this.lblLeftTrunkScale.Size = new System.Drawing.Size(129, 19);
            this.lblLeftTrunkScale.TabIndex = 4;
            this.lblLeftTrunkScale.Text = "左分支长度比";
            // 
            // lblRightTrunkAngle
            // 
            this.lblRightTrunkAngle.AutoSize = true;
            this.lblRightTrunkAngle.Font = new System.Drawing.Font("楷体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblRightTrunkAngle.Location = new System.Drawing.Point(768, 204);
            this.lblRightTrunkAngle.Name = "lblRightTrunkAngle";
            this.lblRightTrunkAngle.Size = new System.Drawing.Size(109, 19);
            this.lblRightTrunkAngle.TabIndex = 5;
            this.lblRightTrunkAngle.Text = "右分支角度";
            // 
            // lblLeftTrunkAngle
            // 
            this.lblLeftTrunkAngle.AutoSize = true;
            this.lblLeftTrunkAngle.Font = new System.Drawing.Font("楷体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblLeftTrunkAngle.Location = new System.Drawing.Point(767, 245);
            this.lblLeftTrunkAngle.Name = "lblLeftTrunkAngle";
            this.lblLeftTrunkAngle.Size = new System.Drawing.Size(109, 19);
            this.lblLeftTrunkAngle.TabIndex = 6;
            this.lblLeftTrunkAngle.Text = "左分支角度";
            // 
            // txtDeepth
            // 
            this.txtDeepth.Font = new System.Drawing.Font("楷体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtDeepth.Location = new System.Drawing.Point(883, 38);
            this.txtDeepth.Name = "txtDeepth";
            this.txtDeepth.Size = new System.Drawing.Size(100, 28);
            this.txtDeepth.TabIndex = 7;
            // 
            // txtMainTrunkLength
            // 
            this.txtMainTrunkLength.Font = new System.Drawing.Font("楷体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtMainTrunkLength.Location = new System.Drawing.Point(883, 80);
            this.txtMainTrunkLength.Name = "txtMainTrunkLength";
            this.txtMainTrunkLength.Size = new System.Drawing.Size(100, 28);
            this.txtMainTrunkLength.TabIndex = 8;
            // 
            // txtRightTrunkScale
            // 
            this.txtRightTrunkScale.Font = new System.Drawing.Font("楷体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtRightTrunkScale.Location = new System.Drawing.Point(883, 122);
            this.txtRightTrunkScale.Name = "txtRightTrunkScale";
            this.txtRightTrunkScale.Size = new System.Drawing.Size(100, 28);
            this.txtRightTrunkScale.TabIndex = 9;
            // 
            // txtLeftTrunkScale
            // 
            this.txtLeftTrunkScale.Font = new System.Drawing.Font("楷体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtLeftTrunkScale.Location = new System.Drawing.Point(883, 161);
            this.txtLeftTrunkScale.Name = "txtLeftTrunkScale";
            this.txtLeftTrunkScale.Size = new System.Drawing.Size(100, 28);
            this.txtLeftTrunkScale.TabIndex = 10;
            // 
            // txtRightTrunkAngle
            // 
            this.txtRightTrunkAngle.Font = new System.Drawing.Font("楷体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtRightTrunkAngle.Location = new System.Drawing.Point(883, 201);
            this.txtRightTrunkAngle.Name = "txtRightTrunkAngle";
            this.txtRightTrunkAngle.Size = new System.Drawing.Size(100, 28);
            this.txtRightTrunkAngle.TabIndex = 11;
            // 
            // txtLeftTrunkAngle
            // 
            this.txtLeftTrunkAngle.Font = new System.Drawing.Font("楷体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtLeftTrunkAngle.Location = new System.Drawing.Point(883, 242);
            this.txtLeftTrunkAngle.Name = "txtLeftTrunkAngle";
            this.txtLeftTrunkAngle.Size = new System.Drawing.Size(100, 28);
            this.txtLeftTrunkAngle.TabIndex = 12;
            // 
            // cmbTreeColor
            // 
            this.cmbTreeColor.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTreeColor.Font = new System.Drawing.Font("楷体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cmbTreeColor.FormattingEnabled = true;
            this.cmbTreeColor.Items.AddRange(new object[] {
            "红色",
            "橙色",
            "黄色",
            "绿色",
            "蓝色",
            "靛色",
            "紫色"});
            this.cmbTreeColor.Location = new System.Drawing.Point(883, 283);
            this.cmbTreeColor.Name = "cmbTreeColor";
            this.cmbTreeColor.Size = new System.Drawing.Size(100, 26);
            this.cmbTreeColor.TabIndex = 13;
            // 
            // lblTreeColor
            // 
            this.lblTreeColor.AutoSize = true;
            this.lblTreeColor.Font = new System.Drawing.Font("楷体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblTreeColor.Location = new System.Drawing.Point(787, 286);
            this.lblTreeColor.Name = "lblTreeColor";
            this.lblTreeColor.Size = new System.Drawing.Size(89, 19);
            this.lblTreeColor.TabIndex = 14;
            this.lblTreeColor.Text = "树的颜色";
            // 
            // drawPanel
            // 
            this.drawPanel.BackColor = System.Drawing.SystemColors.Window;
            this.drawPanel.Location = new System.Drawing.Point(12, 12);
            this.drawPanel.Name = "drawPanel";
            this.drawPanel.Size = new System.Drawing.Size(730, 673);
            this.drawPanel.TabIndex = 15;
            // 
            // lblArgumentsIsLegal
            // 
            this.lblArgumentsIsLegal.AutoSize = true;
            this.lblArgumentsIsLegal.Font = new System.Drawing.Font("楷体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblArgumentsIsLegal.Location = new System.Drawing.Point(748, 325);
            this.lblArgumentsIsLegal.Name = "lblArgumentsIsLegal";
            this.lblArgumentsIsLegal.Size = new System.Drawing.Size(219, 19);
            this.lblArgumentsIsLegal.TabIndex = 16;
            this.lblArgumentsIsLegal.Text = "参数合法与否（Y/N）：";
            // 
            // lblArgumentsIsLegalShow
            // 
            this.lblArgumentsIsLegalShow.AutoSize = true;
            this.lblArgumentsIsLegalShow.Font = new System.Drawing.Font("楷体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblArgumentsIsLegalShow.Location = new System.Drawing.Point(964, 325);
            this.lblArgumentsIsLegalShow.Name = "lblArgumentsIsLegalShow";
            this.lblArgumentsIsLegalShow.Size = new System.Drawing.Size(19, 19);
            this.lblArgumentsIsLegalShow.TabIndex = 17;
            this.lblArgumentsIsLegalShow.Text = "Y";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1006, 697);
            this.Controls.Add(this.lblArgumentsIsLegalShow);
            this.Controls.Add(this.lblArgumentsIsLegal);
            this.Controls.Add(this.drawPanel);
            this.Controls.Add(this.lblTreeColor);
            this.Controls.Add(this.cmbTreeColor);
            this.Controls.Add(this.txtLeftTrunkAngle);
            this.Controls.Add(this.txtRightTrunkAngle);
            this.Controls.Add(this.txtLeftTrunkScale);
            this.Controls.Add(this.txtRightTrunkScale);
            this.Controls.Add(this.txtMainTrunkLength);
            this.Controls.Add(this.txtDeepth);
            this.Controls.Add(this.lblLeftTrunkAngle);
            this.Controls.Add(this.lblRightTrunkAngle);
            this.Controls.Add(this.lblLeftTrunkScale);
            this.Controls.Add(this.lblRightTrunkScale);
            this.Controls.Add(this.lblMainTrunkLength);
            this.Controls.Add(this.lblDeepth);
            this.Controls.Add(this.btnDraw);
            this.Name = "Form1";
            this.Text = "CayleyTree";
            this.Click += new System.EventHandler(this.btnDraw_Click);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnDraw;
        private System.Windows.Forms.Label lblDeepth;
        private System.Windows.Forms.Label lblMainTrunkLength;
        private System.Windows.Forms.Label lblRightTrunkScale;
        private System.Windows.Forms.Label lblLeftTrunkScale;
        private System.Windows.Forms.Label lblRightTrunkAngle;
        private System.Windows.Forms.Label lblLeftTrunkAngle;
        private System.Windows.Forms.TextBox txtDeepth;
        private System.Windows.Forms.TextBox txtMainTrunkLength;
        private System.Windows.Forms.TextBox txtRightTrunkScale;
        private System.Windows.Forms.TextBox txtLeftTrunkScale;
        private System.Windows.Forms.TextBox txtRightTrunkAngle;
        private System.Windows.Forms.TextBox txtLeftTrunkAngle;
        private System.Windows.Forms.ComboBox cmbTreeColor;
        private System.Windows.Forms.Label lblTreeColor;
        private System.Windows.Forms.Panel drawPanel;
        private System.Windows.Forms.Label lblArgumentsIsLegal;
        private System.Windows.Forms.Label lblArgumentsIsLegalShow;
    }
}

