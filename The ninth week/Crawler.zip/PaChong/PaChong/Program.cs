﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace SimpleCrawler
{

    public class SimpleCrawler
    {
        public event Action<string> HasDownloaded;
        public event Action HasFinished;
        public event Action<string> DownloadError;
        private Hashtable urls = new Hashtable();
        public int count = 0;
        public string startUrl = "http://www.cnblogs.com/dstang2000";
        static void Main(string[] args)
        {
            SimpleCrawler myCrawler = new SimpleCrawler();
            //   if (args.Length >= 1) myCrawler.startUrl = args[0];
            myCrawler.Correct_startUrl();
            myCrawler.urls.Add(myCrawler.startUrl, false);//加入初始页面
            new Thread(myCrawler.Crawl).Start();
        }

        public void Crawl()
        {
            //   Console.WriteLine("开始爬行了.... ");
            Correct_startUrl();
            urls.Add(startUrl, false);//加入初始页面
            while (true)
            {
                string current = null;
                foreach (string url in urls.Keys)
                {
                    if ((bool)urls[url]) continue;
                    current = url;
                    break;
                }
                if (current == null || count > 20)//爬完了所有的网址或者爬够10个网址就不再爬取了
                {
                    HasFinished();
                    break;
                }
                //将相对地址转变成绝对地址
                string currentOriginal = current;//为了防止丢失对current原始字符串在堆中的引用
                if (current[0] == '/')
                {
                    string startURL= startUrl.Remove(startUrl.Length - 1, 1);
                    current = startURL + current;
                }
                if (current[0] != '/'&&current[0] != 'h' & current[1] != 't' & current[2] != 't' & current[3] != 'p' & current[4] != ':')
                    current = startUrl + current;

                Regex regex = new Regex("www.");
                Match match=regex.Match(startUrl);
                string LocalWeb=startUrl.Remove(0, match.Index);
             if (Regex.IsMatch(current, LocalWeb))
             {
                    //   Console.WriteLine("爬行" + current + "页面!");
                count++;
                string html = DownLoad(current); // 下载
                urls[currentOriginal] = true;
                    if (html == "")
                        ;
                    //      Console.WriteLine("由于网页异常，此次爬行失败");
                    else
                    {
                      if (IsHtml(html))//如果是html格式我才解析
                          Parse(html);//解析,并加入新的链接
                   //     Console.WriteLine("爬行结束");
                    }
                }
             else
                urls[currentOriginal] = true;
        /*       
                Console.WriteLine("爬行" + current + "页面!");
                string html = DownLoad(current); // 下载
                urls[current] = true;
                count++;
                Parse(html);//解析,并加入新的链接
                Console.WriteLine("爬行结束");
          */
            }
        }

        public string DownLoad(string url)//将目标URL的资源下载成字符串写到一个文件里，文件名是爬虫的爬次
        {
            try
            {
                WebClient webClient = new WebClient();
                webClient.Encoding = Encoding.UTF8;
                string html = webClient.DownloadString(url);
                string fileName = count.ToString();
                File.WriteAllText(fileName, html, Encoding.UTF8);
                HasDownloaded(url);
                return html;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                DownloadError(url);
                return "";
            }
        }

        private void Parse(string html)
        {
            string strRef = @"(href|HREF)[]*=[]*[""'][^""'#>]+[""']";
            MatchCollection matches = new Regex(strRef).Matches(html);
            foreach (Match match in matches)
            {
                strRef = match.Value.Substring(match.Value.IndexOf('=') + 1)
                          .Trim('"', '\"', '#', '>');
                if (strRef.Length == 0) continue;
                if (urls[strRef] == null) urls[strRef] = false;
            }
        }

        private void Correct_startUrl()
        {
            if (startUrl[startUrl.Length - 1] != '/')
                startUrl = startUrl + "/";
        }

        private bool IsHtml(string html)
        {
           return Regex.IsMatch(html, "^<!DOCTYPE html>");
        }
    }
}
