﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SimpleCrawler;
using System.Threading;
namespace Crawler
{
    public partial class Form1 : Form
    {
        SimpleCrawler.SimpleCrawler myCrawler;
        public Form1()
        {
            InitializeComponent();
            myCrawler = new SimpleCrawler.SimpleCrawler();
            myCrawler.HasDownloaded += Crawler_PageDownloaded;
            myCrawler.HasFinished += Crawler_Finished;
            myCrawler.DownloadError += Crawler_DownloadError;

        }

        private void Crawler_PageDownloaded(string obj)
        {

            if (this.lst_hasDownloaded.InvokeRequired)
            {
                Action<String> action = this.AddUrl;
                this.Invoke(action, new object[] { "成功爬取："+obj });
            }
            else
            {
                lst_hasDownloaded.Items.Add("成功爬取：" + obj);

            }
        }

        private void Crawler_Finished()
        {

            if (this.lst_hasDownloaded.InvokeRequired)
            {
                Action<String> action = this.AddUrl;
                this.Invoke(action, new object[] { "爬取完成" });
            }
            else
            {
                lst_hasDownloaded.Items.Add("爬取完成");

            }
        }

        private void Crawler_DownloadError(string obj)
        {

            if (this.lst_hasDownloaded.InvokeRequired)
            {
                Action<String> action = this.AddUrl;
                this.Invoke(action, new object[] { "爬取失败：" + obj });
            }
            else
            {
                lst_hasDownloaded.Items.Add("爬取失败：" + obj);

            }
        }


        private void AddUrl(string url)
        {
            lst_hasDownloaded.Items.Add(url);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_StartCrawl_Click(object sender, EventArgs e)
        {
            myCrawler.startUrl = txt_InitialUrl.Text;
            lst_hasDownloaded.Items.Clear();
            new Thread(myCrawler.Crawl).Start();

        }


    }
}
