﻿namespace Crawler
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_InitialUrl = new System.Windows.Forms.Label();
            this.txt_InitialUrl = new System.Windows.Forms.TextBox();
            this.lst_hasDownloaded = new System.Windows.Forms.ListBox();
            this.btn_StartCrawl = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_InitialUrl
            // 
            this.lbl_InitialUrl.AutoSize = true;
            this.lbl_InitialUrl.Location = new System.Drawing.Point(12, 39);
            this.lbl_InitialUrl.Name = "lbl_InitialUrl";
            this.lbl_InitialUrl.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbl_InitialUrl.Size = new System.Drawing.Size(82, 15);
            this.lbl_InitialUrl.TabIndex = 0;
            this.lbl_InitialUrl.Text = "起始网址：";
            // 
            // txt_InitialUrl
            // 
            this.txt_InitialUrl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_InitialUrl.Location = new System.Drawing.Point(100, 34);
            this.txt_InitialUrl.Name = "txt_InitialUrl";
            this.txt_InitialUrl.Size = new System.Drawing.Size(752, 25);
            this.txt_InitialUrl.TabIndex = 1;
            // 
            // lst_hasDownloaded
            // 
            this.lst_hasDownloaded.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lst_hasDownloaded.FormattingEnabled = true;
            this.lst_hasDownloaded.ItemHeight = 15;
            this.lst_hasDownloaded.Location = new System.Drawing.Point(15, 79);
            this.lst_hasDownloaded.Name = "lst_hasDownloaded";
            this.lst_hasDownloaded.Size = new System.Drawing.Size(944, 319);
            this.lst_hasDownloaded.TabIndex = 2;
            // 
            // btn_StartCrawl
            // 
            this.btn_StartCrawl.Location = new System.Drawing.Point(858, 34);
            this.btn_StartCrawl.Name = "btn_StartCrawl";
            this.btn_StartCrawl.Size = new System.Drawing.Size(101, 25);
            this.btn_StartCrawl.TabIndex = 3;
            this.btn_StartCrawl.Text = "开始爬取";
            this.btn_StartCrawl.UseVisualStyleBackColor = true;
            this.btn_StartCrawl.Click += new System.EventHandler(this.btn_StartCrawl_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(971, 415);
            this.Controls.Add(this.btn_StartCrawl);
            this.Controls.Add(this.lst_hasDownloaded);
            this.Controls.Add(this.txt_InitialUrl);
            this.Controls.Add(this.lbl_InitialUrl);
            this.Name = "Form1";
            this.Text = "简单爬虫";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_InitialUrl;
        private System.Windows.Forms.TextBox txt_InitialUrl;
        private System.Windows.Forms.ListBox lst_hasDownloaded;
        private System.Windows.Forms.Button btn_StartCrawl;
    }
}

