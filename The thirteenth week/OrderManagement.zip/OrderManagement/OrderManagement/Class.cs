﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace OrderManagement
{
    public class Order
    {
        [Key]
        public int Orderid { get; set; }
        public DateTime CreateTime { get; set; }
        public List<OrderItem> OrderItems { get; set; }
        [Required]
        public int CustomerId { get; set; }
        [ForeignKey("CustomerId")]
        public Customer customer { get; set; }//在创建order时，把customer设置为null，这样使得CustomerId起作用，避免CustomerId与customer不一致的问题
        public double TotalPrice { get; set; }
    }
    public class Customer
    {
        public int CustomerId { get; set; }
        [Required]
        public string Name { get; set; }
        public string Gender { get; set; }
        public int Age { get; set; }
    }
    public class OrderItem
    {
        public int OrderItemId { get; set; }
        [Required]
        public string GoodsName { get; set; }
        [Required]
        public double quantity { get; set; }
        [Required]
        public double price { get; set; }
        public int OrderId { get; set; }

    }
    public class OrderManagementContext : DbContext
    {
        public OrderManagementContext(DbContextOptions<OrderManagementContext> options) : base(options)
        {
            this.Database.EnsureCreated();
        }

        public DbSet<Order> Orders { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }
    }
    public class OrderManagementException : ApplicationException//自定义的异常类型
    {
        private int code;
        public int Code { get => code; }
        public OrderManagementException(string message, int code) : base(message)
        {
            this.code = code;

        }

    }


}
