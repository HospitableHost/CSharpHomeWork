﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using OrderManagement;

namespace OrderControllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrderController : ControllerBase
    {
        private readonly OrderManagementContext OrderManagementDb;

        public OrderController(OrderManagementContext context)
        {
            this.OrderManagementDb = context;
        }

        // GET: api/order/{id}  id为路径参数
        [HttpGet("{id}")]
        public ActionResult<Order> GetOrder(int id)
        {
            var order = OrderManagementDb.Orders.FirstOrDefault(o => o.Orderid == id);
            if (order == null)
            {
                return NotFound();
            }
            if(order.customer==null)
            {
                order.customer = OrderManagementDb.Customers.FirstOrDefault(c => c.CustomerId == order.CustomerId);
            }
            if(order.OrderItems == null)
            {
                order.OrderItems = new List<OrderItem>();
                foreach(OrderItem item in OrderManagementDb.OrderItems)
                {
                    if (item.OrderId == id  && !order.OrderItems.Contains(item))
                        order.OrderItems.Add(item);                                                              
                }
                if (order.OrderItems.Count == 0)
                    order.OrderItems = null;
            }
            return order;
        }

        // GET: api/order/customer
        [HttpGet("customer")]
        public ActionResult<List<Customer>> GetCustomers()
        {
            var customers = OrderManagementDb.Customers.ToList();
            return customers;
        }

        // GET: api/order/orderitem
        [HttpGet("orderitem")]
        public ActionResult<List<OrderItem>> GetOrderitems()
        {
            var orderitems = OrderManagementDb.OrderItems.ToList();
            return orderitems;
        }


        // GET: api/order
        // GET: api/order?name=顾客名
        [HttpGet]
        public ActionResult<List<Order>> GetOrder(string name)
        {
            if(name == null)
            {
                List<Order> orderss = OrderManagementDb.Orders.ToList();
                foreach(Order order in orderss)
                {
                    if (order.customer == null)
                    {
                        order.customer = OrderManagementDb.Customers.FirstOrDefault(c => c.CustomerId == order.CustomerId);
                    }
                    if (order.OrderItems == null)
                    {
                        order.OrderItems = new List<OrderItem>();
                        foreach (OrderItem item in OrderManagementDb.OrderItems)
                        {
                            if (item.OrderId == order.Orderid && !order.OrderItems.Contains(item))
                                order.OrderItems.Add(item);
                        }
                        if (order.OrderItems.Count == 0)
                            order.OrderItems = null;
                    }
                }
                return orderss;
            }
            List<Order> orders = new List<Order>();
            Customer customer = OrderManagementDb.Customers.FirstOrDefault(c => c.Name == name);
            if(customer == null)
                return NotFound();            
            foreach (Order o in OrderManagementDb.Orders)
            {
                if (o.CustomerId == customer.CustomerId)
                    orders.Add(o);
            }
            foreach (Order order in orders)
            {
                if (order.customer == null)
                {
                    order.customer = OrderManagementDb.Customers.FirstOrDefault(c => c.CustomerId == order.CustomerId);
                }
                if (order.OrderItems == null)
                {
                    order.OrderItems = new List<OrderItem>();
                    foreach (OrderItem item in OrderManagementDb.OrderItems)
                    {
                        if (item.OrderId == order.Orderid && !order.OrderItems.Contains(item))
                            order.OrderItems.Add(item);
                    }
                    if (order.OrderItems.Count == 0)
                        order.OrderItems = null;
                }
            }
            if (orders.Count == 0)
                return NotFound();
            else
                return orders;


        }

        // POST: api/order
        [HttpPost]
        public ActionResult<Order> PostOrder(Order o)
        {
            try
            {
                if(o.customer != null && o.customer.CustomerId != o.CustomerId)
                {
                    OrderManagementException e = new OrderManagementException("顾客号与顾客不一致",1);
                    throw e;
                }
                if(o.customer != null && OrderManagementDb.Customers.FirstOrDefault(c=>c.CustomerId == o.CustomerId).Name!=o.customer.Name)
                {
                    OrderManagementException e = new OrderManagementException("顾客号与顾客不一致",1);
                    throw e;
                }
                OrderManagementDb.Orders.Add(o);
                OrderManagementDb.SaveChanges();
            }
            catch (Exception e)
            {
                return BadRequest(e.InnerException.Message);
            }
            return o;
        }

        // POST: api/order/customer
        [HttpPost("customer")]
        public ActionResult<Customer> PostCustomer(Customer customer)
        {
            try
            {
                OrderManagementDb.Customers.Add(customer);
                OrderManagementDb.SaveChanges();
            }
            catch (Exception e)
            {
                return BadRequest(e.InnerException.Message);
            }
            return customer;
        }

        // POST: api/order/orderitem
        [HttpPost("orderitem")]
        public ActionResult<OrderItem> PostOrderitem(OrderItem orderItem)
        {
            try
            {
                OrderManagementDb.OrderItems.Add(orderItem);
                OrderManagementDb.SaveChanges();
            }
            catch (Exception e)
            {
                return BadRequest(e.InnerException.Message);
            }
            return orderItem;
        }


        // PUT: api/order/{id}
        [HttpPut("{id}")]
        public ActionResult<Order> PutOrder(int id, Order order)
        {
            if (id != order.Orderid)
            {
                return BadRequest("Id cannot be modified!");
            }
            try
            {
                OrderManagementDb.Entry(order).State = EntityState.Modified;
                OrderManagementDb.SaveChanges();
            }
            catch (Exception e)
            {
                string error = e.Message;
                if (e.InnerException != null) error = e.InnerException.Message;
                return BadRequest(error);
            }
            return NoContent();
        }

        // DELETE: api/order/{id}
        [HttpDelete("{id}")]
        public ActionResult DeleteOrder(int id)
        {
            try
            {
                var o = OrderManagementDb.Orders.Include("OrderItems").FirstOrDefault(p => p.Orderid == id);
                if (o != null)
                {
                    OrderManagementDb.Remove(o);
                    OrderManagementDb.SaveChanges();
                }
            }
            catch (Exception e)
            {
                return BadRequest(e.InnerException.Message);
            }
            return NoContent();
        }

    }
}
