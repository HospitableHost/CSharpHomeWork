﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using 订单管理程序;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace 订单管理程序.Tests
{
    [TestClass()]
    public class OrderServiceTests
    {
        [TestInitialize]
        public void InitializeBeforeTest()
        {
            //定义4个顾客、5个订单项、6个订单项列表、6个订单，再把6个订单加入到OrderService的订单列表中
            Customer customer1 = new Customer("党自强", "男", "洪山区武汉大学信息学部学生宿舍13舍", 20, "17396156570");
            Customer customer2 = new Customer("方正", "男", "洪山区武汉大学信息学部学生宿舍13舍", 19, "17396156571");
            Customer customer3 = new Customer("王涛", "男", "洪山区武汉大学信息学部学生宿舍13舍", 20, "17396156572");
            Customer customer4 = new Customer("沈志豪", "男", "洪山区武汉大学信息学部学生宿舍13舍", 20, "17396156573");
            OrderItem orderItem1 = new OrderItem("AK47", 600, 3);
            OrderItem orderItem2 = new OrderItem("UZI", 400, 1);
            OrderItem orderItem3 = new OrderItem("AK74", 500, 5);
            OrderItem orderItem4 = new OrderItem("M4A1", 550, 2);
            OrderItem orderItem5 = new OrderItem("巴雷特", 900, 1);
            List<OrderItem> orderItems1 = new List<OrderItem>();
            List<OrderItem> orderItems2 = new List<OrderItem>();
            List<OrderItem> orderItems3 = new List<OrderItem>();
            List<OrderItem> orderItems4 = new List<OrderItem>();
            List<OrderItem> orderItems5 = new List<OrderItem>();
            List<OrderItem> orderItems6 = new List<OrderItem>();
            orderItems1.Add(orderItem1); orderItems1.Add(orderItem2);
            orderItems2.Add(orderItem1); orderItems2.Add(orderItem2); orderItems2.Add(orderItem3);
            orderItems3.Add(orderItem4); orderItems3.Add(orderItem5);
            orderItems4.Add(orderItem5);
            orderItems5.Add(orderItem1); orderItems5.Add(orderItem2); orderItems5.Add(orderItem3); orderItems5.Add(orderItem5);
            orderItems6.Add(orderItem1);
            Order o1 = new Order(1, orderItems1, customer1);
            Order o2 = new Order(2, orderItems2, customer1);
            Order o3 = new Order(3, orderItems3, customer1);
            Order o4 = new Order(4, orderItems4, customer2);
            Order o5 = new Order(5, orderItems5, customer3);
            Order o6 = new Order(6, orderItems6, customer4);
            OrderService.orders.Add(o1);
            OrderService.orders.Add(o3);
            OrderService.orders.Add(o4);
            OrderService.orders.Add(o2);
            OrderService.orders.Add(o6);
            OrderService.orders.Add(o5);
        }

        [TestCleanup]
        public void CleanUpAfterTest()
        {
            OrderService.orders.Clear();
        }

        [TestMethod()]
        public void AddOrderTest0()//添加功能测试
        {
            OrderItem orderItem1 = new OrderItem("AK47", 600, 3);
            OrderItem orderItem2 = new OrderItem("UZI", 400, 1);
            List<OrderItem> orderItems1 = new List<OrderItem>();
            orderItems1.Add(orderItem1); orderItems1.Add(orderItem2);
            Customer customer1 = new Customer("党自强", "男", "洪山区武汉大学信息学部学生宿舍13舍", 20, "17396156570");
            OrderService.AddOrder(20, orderItems1, customer1);
            Order o=OrderService.orders.Last();
            if (o.Orderid == 20 && o.customer == customer1 && o.Orderitem == orderItems1)
                return;
            else
                Assert.Fail();
        }

        [TestMethod()]
        [ExpectedException(typeof(OrderManagementException))]
        public void AddOrderTest1()//订单号重复，添加失败测试
        {
            OrderItem orderItem1 = new OrderItem("AK47", 600, 3);
            OrderItem orderItem2 = new OrderItem("UZI", 400, 1);
            List<OrderItem> orderItems1 = new List<OrderItem>();
            orderItems1.Add(orderItem1); orderItems1.Add(orderItem2);
            Customer customer1 = new Customer("党自强", "男", "洪山区武汉大学信息学部学生宿舍13舍", 20, "17396156570");
            OrderService.AddOrder(2, orderItems1, customer1);
        }

        [TestMethod()]
        [ExpectedException(typeof(OrderManagementException))]
        public void AddOrderTest2()//订单项列表为空引用，添加失败测试
        {
            Customer customer1 = new Customer("党自强", "男", "洪山区武汉大学信息学部学生宿舍13舍", 20, "17396156570");
            OrderService.AddOrder(20, null, customer1);
        }

        [TestMethod()]
        [ExpectedException(typeof(OrderManagementException))]
        public void AddOrderTest3()//订单项列表为空，添加失败测试
        {
            Customer customer1 = new Customer("党自强", "男", "洪山区武汉大学信息学部学生宿舍13舍", 20, "17396156570");
            List<OrderItem> orderItems = new List<OrderItem>();
            OrderService.AddOrder(20, orderItems, customer1);
        }

        [TestMethod()]
        [ExpectedException(typeof(OrderManagementException))]
        public void AddOrderTest4()//顾客为空引用，添加失败测试
        {
            OrderItem orderItem1 = new OrderItem("AK47", 600, 3);
            OrderItem orderItem2 = new OrderItem("UZI", 400, 1);
            List<OrderItem> orderItems1 = new List<OrderItem>();
            orderItems1.Add(orderItem1); orderItems1.Add(orderItem2);
            OrderService.AddOrder(20, orderItems1, null);
        }

        [TestMethod()]
        public void ModifyOrderTest0()//修改功能测试
        {
            OrderItem orderItem1 = new OrderItem("AK47", 600, 3);
            OrderItem orderItem2 = new OrderItem("UZI", 400, 1);
            List<OrderItem> orderItems1 = new List<OrderItem>();
            orderItems1.Add(orderItem1); orderItems1.Add(orderItem2);
            Customer customer1 = new Customer("党自强", "男", "洪山区武汉大学信息学部学生宿舍13舍", 20, "17396156570");
            OrderService.ModifyOrder(5, customer1,orderItems1);
            Order o = OrderService.orders[5];
            if (o.customer == customer1 && o.Orderitem == orderItems1)
                return;
            else
                Assert.Fail();
        }

        [TestMethod()]
        [ExpectedException(typeof(OrderManagementException))]
        public void ModifyOrderTest1()//订单不存在，修改失败测试
        {
            OrderItem orderItem1 = new OrderItem("AK47", 600, 3);
            OrderItem orderItem2 = new OrderItem("UZI", 400, 1);
            List<OrderItem> orderItems1 = new List<OrderItem>();
            orderItems1.Add(orderItem1); orderItems1.Add(orderItem2);
            Customer customer1 = new Customer("党自强", "男", "洪山区武汉大学信息学部学生宿舍13舍", 20, "17396156570");
            OrderService.ModifyOrder(200,customer1,orderItems1);
        }

        [TestMethod()]
        [ExpectedException(typeof(OrderManagementException))]
        public void ModifyOrderTest2()//订单项列表为空引用，修改失败测试
        {
            Customer customer1 = new Customer("党自强", "男", "洪山区武汉大学信息学部学生宿舍13舍", 20, "17396156570");
            OrderService.ModifyOrder(1,customer1,null);
        }

        [TestMethod()]
        [ExpectedException(typeof(OrderManagementException))]
        public void ModifyOrderTest3()//订单项列表为空，修改失败测试
        {
            Customer customer1 = new Customer("党自强", "男", "洪山区武汉大学信息学部学生宿舍13舍", 20, "17396156570");
            List<OrderItem> orderItems = new List<OrderItem>();
            OrderService.ModifyOrder(1, customer1,orderItems);
        }
        
        [TestMethod()]
        [ExpectedException(typeof(OrderManagementException))]
        public void ModifyOrderTest4()//顾客为空引用，修改失败测试
        {
            OrderItem orderItem1 = new OrderItem("AK47", 600, 3);
            OrderItem orderItem2 = new OrderItem("UZI", 400, 1);
            List<OrderItem> orderItems1 = new List<OrderItem>();
            orderItems1.Add(orderItem1); orderItems1.Add(orderItem2);
            OrderService.ModifyOrder(1, null,orderItems1);
        }

        [TestMethod()]
        public void DeleteOrderTest0()//删除订单功能测试
        {
            OrderService.DeleteOrder(5);
            if (OrderService.orders.Last().Orderid == 6)
                return;
            else
                Assert.Fail();
        }

        [TestMethod()]
        [ExpectedException(typeof(OrderManagementException))]
        public void DeleteOrderTest1()//订单不存在，无法删除测试
        {
            OrderService.DeleteOrder(200);
        }

        [TestMethod()]
        public void SearchOrderTest1()//按订单号查询，查找出已存在的订单测试
        {
            Order o = OrderService.SearchOrder(1);
            Assert.AreEqual(o.Orderid,1);
        }

        [TestMethod()]
        public void SearchOrderTest2()//按订单号查询，找不到订单时，返回值为null的测试
        {
            Assert.AreEqual(OrderService.SearchOrder(100),null);
        }

        [TestMethod()]
        public void SearchOrderTest3()//按顾客名查询，查找出已存在的订单测试
        {
            var query = OrderService.SearchOrder("党自强");
            foreach (Order o in query)
                if (o.customer.Name != "党自强")
                    Assert.Fail();
            if(query.Count()!=3)
                 Assert.Fail();
        }

        [TestMethod()]
        public void SearchOrderTest4()//按顾客名查询，找不到订单时，返回的枚举器中元素数量为0的测试
        {
            var query = OrderService.SearchOrder("赵云");
            if (query.Count() != 0)
                Assert.Fail();
        }

        [TestMethod()]
        public void SearchOrderByGoodsNameTest1()//按商品名查询，查找出已存在的订单测试
        {
            var query = OrderService.SearchOrderByGoodsName("AK47");
            foreach (Order o in query)
                if (!OrderService.ContainGoods("AK47", o))
                    Assert.Fail();
            if (query.Count() != 4)
                Assert.Fail();
        }

        [TestMethod()]
        public void SearchOrderByGoodsNameTest2()//按商品名查询，找不到订单时，返回的枚举器中元素数量为0的测试
        {
            var query = OrderService.SearchOrderByGoodsName("M16");
            if (query.Count() != 0)
                Assert.Fail();
        }

        [TestMethod()]
        public void ContainGoodsTest()//测试包含和不包含商品两个方面
        {
            if(!OrderService.ContainGoods("AK47",OrderService.orders[0]))
                Assert.Fail();
            if(OrderService.ContainGoods("M4A1", OrderService.orders[0]))
                Assert.Fail();
        }

        [TestMethod()]
        public void Sort1Test()//无参数的排序函数的测试
        {
            OrderService.Sort();
            for (int i = 0; i < 6; i++)
                if (OrderService.orders[i].Orderid != i + 1)
                    Assert.Fail();
                   
        }

        [TestMethod()]
        [ExpectedException(typeof(OrderManagementException))]
        public void Sort2Test1()//参数为委托实例的排序函数测试委托为null抛出异常
        {
            OrderService.Sort(null);
        }

        [TestMethod()]
        public void Sort2Test2()//参数为委托实例的排序函数排序功能测试
        {
            OrderService.Sort(( o1, o2)=> o1.Orderid-o2.Orderid );
            for (int i = 0; i < 6; i++)
                if (OrderService.orders[i].Orderid != i + 1)
                    Assert.Fail();
        }

        [TestMethod()]
        public void ExportToXMLTest()
        {
            OrderService.ExportToXML();
            if (!File.Exists(@"C:\Users\ASUS\source\repos\ConsoleApp\ConsoleAppTests\bin\Debug\Orders.xml"))
                Assert.Fail();
            List<Order> ordersFromXml = OrderService.ImportFromXML(@"C:\Users\ASUS\source\repos\ConsoleApp\ConsoleAppTests\bin\Debug\Orders.xml");
            for (int i = 0; i < 6; i++)
                if ((OrderService.orders[i].Orderid != ordersFromXml[i].Orderid)|| !(OrderService.orders[i].customer.Equals(ordersFromXml[i].customer)) )
                    Assert.Fail();

        }

        [TestMethod()]
        [ExpectedException(typeof(FileNotFoundException))]
        public void ImportFromXMLTest1()//文件不存在测试
        {
            OrderService.ImportFromXML(@"C:\Users\ASUS\source\repos\ConsoleApp\ConsoleAppTests\bin\Debug\Ordersssss.xml");
        }

        [TestMethod()]
        [ExpectedException(typeof(ArgumentException))]
        public void ImportFromXMLTest2()
        {
            OrderService.ImportFromXML(@"C:\Users\ASUS\source\repos\ConsoleApp\ConsoleAppTests\bin\Debug\Orders.docx");
        }

        [TestMethod()]
        public void ImportFromXMLTest3()
        {
            OrderService.ExportToXML();
            List<Order> ordersFromXml = OrderService.ImportFromXML(@"C:\Users\ASUS\source\repos\ConsoleApp\ConsoleAppTests\bin\Debug\Orders.xml");
            for (int i = 0; i < 6; i++)
                if ((OrderService.orders[i].Orderid != ordersFromXml[i].Orderid) || !(OrderService.orders[i].customer.Equals(ordersFromXml[i].customer)))
                    Assert.Fail();

        }

    }
}