﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OrderManagementWithMySql;

namespace OrderManagement
{
    class Program
    {
        static void Main(string[] args)
        {
            //依次执行第一部分和第二部分代码可以看到数据库的变化,一起执行的话只能看到最终的结果
            //第一次所执行的代码，把下边第二部分给注释点，以此获得起始数据库，当然如果不想看其实数据库长什么样子的话可以两部分一起执行
            
            Customer customer1 = new Customer() { CustomerId = 1, Name = "党自强", Gender = "男", Age = 20 };
            Customer customer2 = new Customer() { CustomerId = 2, Name = "王涛", Gender = "男", Age = 20 };
            Customer customer3 = new Customer() { CustomerId = 3, Name = "方正", Gender = "男", Age = 19 };
            Order order1 = new Order() { Orderid = 1, CreateTime = DateTime.Now, CustomerId = 1 };
            Order order2 = new Order() { Orderid = 2, CreateTime = DateTime.Now, CustomerId = 1 };
            Order order3 = new Order() { Orderid = 3, CreateTime = DateTime.Now, CustomerId = 1 };
            Order order4 = new Order() { Orderid = 4, CreateTime = DateTime.Now, CustomerId = 2 };
            Order order5 = new Order() { Orderid = 5, CreateTime = DateTime.Now, CustomerId = 3 };
            OrderItem item1 = new OrderItem() { OrderItemId = 1, GoodsName = "AK47", OrderId = 1, price = 6000, quantity = 3 };
            OrderItem item2 = new OrderItem() { OrderItemId = 2, GoodsName = "M4A1", OrderId = 1, price = 9000, quantity = 2 };
            OrderItem item3 = new OrderItem() { OrderItemId = 3, GoodsName = "M16", OrderId = 1, price = 7000, quantity = 3 };
            OrderItem item4 = new OrderItem() { OrderItemId = 4, GoodsName = "AK47", OrderId = 2, price = 6000, quantity = 1 };
            OrderItem item5 = new OrderItem() { OrderItemId = 5, GoodsName = "AK47", OrderId = 3, price = 6000, quantity = 2 };
            OrderItem item6 = new OrderItem() { OrderItemId = 6, GoodsName = "AK47", OrderId = 4, price = 6000, quantity = 5 };
            OrderItem item7 = new OrderItem() { OrderItemId = 7, GoodsName = "巴雷特", OrderId = 5, price = 10000, quantity = 6 };
            OrderService.AddCustomer(customer1);
            OrderService.AddCustomer(customer2);
            OrderService.AddCustomer(customer3);
            OrderService.AddOrder(order1);
            OrderService.AddOrder(order2);
            OrderService.AddOrder(order3);
            OrderService.AddOrder(order4);
            OrderService.AddOrder(order5);
            OrderService.AddOrderItem(item1);
            OrderService.AddOrderItem(item2);
            OrderService.AddOrderItem(item3);
            OrderService.AddOrderItem(item4);
            OrderService.AddOrderItem(item5);
            OrderService.AddOrderItem(item6);
            OrderService.AddOrderItem(item7);
            for(int i=1; i<6;i++)
              OrderService.CorrectTotalPrice(i);
            
            
            //第二部分执行代码
            
            OrderService.ModifyOrder(1, 3);
            OrderItem item8 = new OrderItem() { OrderItemId = 8, GoodsName = "巴雷特", OrderId = 2, price = 10000, quantity = 6 };
            OrderService.ModifyOrder(2, item8);
            OrderService.ModifyOrder(3, "AK47");
            OrderService.DeleteOrder(4);
            Order o = OrderService.SearchOrder(1);
            Console.WriteLine("订单号：" + o.Orderid + ",顾客ID：" + o.CustomerId);
            List<Order> os = OrderService.Search(1);
            foreach (Order oo in os)
                Console.WriteLine("订单号：" + oo.Orderid + ",顾客ID：" + oo.CustomerId);
            
        }
    }
}
