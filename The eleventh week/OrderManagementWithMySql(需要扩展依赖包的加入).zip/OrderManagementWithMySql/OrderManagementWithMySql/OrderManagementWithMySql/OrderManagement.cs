﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;

namespace OrderManagementWithMySql
{
    public class Order
    {
        [Key]
        public int Orderid { get; set; }
        public DateTime CreateTime { get; set; }
        public List<OrderItem> OrderItems { get; set; }
        [Required]
        public int CustomerId { get; set; }
        [ForeignKey("CustomerId")]
        public Customer customer { get; set; }//在创建order时，把customer设置为null，这样使得CustomerId起作用，避免CustomerId与customer不一致的问题
        public double TotalPrice { get; set; }
    }
    public class Customer
    {
        public int CustomerId { get; set; }
        [Required]
        public string Name { get; set; }
        public string Gender { get; set; }
        public int Age { get; set; }
        public List<Order> orders { get; set; }
    }
    public class OrderItem
    {
        public int OrderItemId { get; set; }
        [Required]
        public string GoodsName { get; set; }
        [Required]
        public double quantity { get; set; }
        [Required]
        public double price { get; set; }
        public int OrderId { get; set; }
        [ForeignKey("OrderId")]
        public Order order { get; set; }

    }
    public class OrderManagementContext : DbContext
    {
        public OrderManagementContext() : base("OrderManagementBase")
        {
            Database.SetInitializer(
              new DropCreateDatabaseIfModelChanges<OrderManagementContext>());
        }

        public DbSet<Order> Orders { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }
    }
    public class OrderService
    {
        public static void AddOrder(Order order)
        {
            if (order == null)
                throw new OrderManagementException("添加的订单对象为null", 3);
            using (var context = new OrderManagementContext())
            {
                context.Entry(order).State = EntityState.Added;
                context.SaveChanges();
            }
        }
        public static void DeleteOrder(int OrderID)//通过订单号去删除订单,就算这个订单ID对应的订单不存在，那也什么都没有做，也可以认为删除成功
        {
            using (var context = new OrderManagementContext())
            {
                var o = context.Orders.Include("OrderItems").First(p => p.Orderid == OrderID);
                if (o == null)
                    return;
                context.Orders.Remove(o);
                context.SaveChanges();
            }
        }
        public static void ModifyOrder(int OrderID,int CustomerID)//通过订单号OrderID修改CustomerID
        {
            using (var context = new OrderManagementContext())
            {
                Order o = context.Orders.First(p => p.Orderid == OrderID);
                if (o == null)
                    throw new OrderManagementException("订单不存在，修改订单失败", 3);
                o.CustomerId = CustomerID;
                context.SaveChanges();
            }
        }
        public static void ModifyOrder(int OrderID,OrderItem orderItem)//向OrderID对应的订单中新增一个订单项
        {
            using (var context = new OrderManagementContext())
            {
                Order o = context.Orders.First(p => p.Orderid == OrderID);
                if (o == null)
                    throw new OrderManagementException("订单不存在，增加订单项失败", 4);
                orderItem.OrderId = OrderID;
                AddOrderItem(orderItem);
                CorrectTotalPrice(OrderID);
            }
        }
        public static void ModifyOrder(int OrderID,string goods_name)//将OrderID对应的订单中的名为goods_name的订单项删除,就算这个对应的订单项不存在，那也什么都没有做，也可以认为删除成功
        {
            using (var context = new OrderManagementContext())
            {
                OrderItem item = context.OrderItems.First(p => p.OrderId == OrderID && p.GoodsName == goods_name);
                if (item == null)
                    return;
                context.OrderItems.Remove(item);
                context.SaveChanges();
                CorrectTotalPrice(OrderID);
            }
        }
        public static void CorrectTotalPrice(int OrderID)
        {
            using (var context = new OrderManagementContext())
            {
                Order o = context.Orders.First(p => p.Orderid == OrderID);
                if (o == null)
                    throw new OrderManagementException("订单不存在，纠正订单总价失败", 5);
                var query = context.OrderItems.Where(item => item.OrderId == OrderID);
                double totalPrice = 0;
                foreach (OrderItem item in query)
                    totalPrice += (item.price) * (item.quantity);
                o.TotalPrice = totalPrice;
                context.SaveChanges();

            }
        }
        public static Order SearchOrder(int OrderID)//通过订单号查询订单，返回对应的Order对象
        {
            using (var context = new OrderManagementContext())
            {
                Order o = context.Orders.First(p => p.Orderid == OrderID);
                return o;
            }
        }
        public static List<Order> Search(int CustomerID)//通过顾客号查找订单，将查找到的所有订单返回
        {
            using (var context = new OrderManagementContext())
            {
               var query = context.Orders.Where(o => o.CustomerId == CustomerID);
               List<Order> orders = query.ToList();
                return orders;
            }
        }
        public static void AddCustomer(Customer customer)
        {
            if (customer == null)
                throw new OrderManagementException("添加的顾客对象为null", 2);
            using (var context = new OrderManagementContext())
            {
                context.Entry(customer).State = EntityState.Added;
                context.SaveChanges();
            }
        }
        public static void AddOrderItem (OrderItem orderItem)
        {
            if (orderItem == null)
                throw new OrderManagementException("添加的订单项对象为null", 1);
            using (var context = new OrderManagementContext())
            {
                context.Entry(orderItem).State = EntityState.Added;
                context.SaveChanges();
            }
        }
        public static void DeleteOrderItem(int OrderID)//根据OrderID删除相应订单的所有订单项,就算这个订单ID对应的订单项不存在，那也什么都没有做，也可以认为删除成功
        {
            using (var context = new OrderManagementContext())
            {
                while (true)
                {
                    OrderItem item = context.OrderItems.First(p => p.OrderId == OrderID);
                    if (item == null)
                        break;
                    context.OrderItems.Remove(item);
                    context.SaveChanges();
                }
            }

        }
    }
    public class OrderManagementException : ApplicationException//自定义的异常类型
    {
        private int code;
        public int Code { get => code; }
        public OrderManagementException(string message, int code) : base(message)
        {
            this.code = code;

        }

    }

}
