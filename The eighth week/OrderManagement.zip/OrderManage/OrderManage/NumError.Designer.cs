﻿namespace OrderManage
{
    partial class NumError
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNumError = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblNumError
            // 
            this.lblNumError.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblNumError.AutoSize = true;
            this.lblNumError.Font = new System.Drawing.Font("李旭科书法", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblNumError.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblNumError.Location = new System.Drawing.Point(96, 41);
            this.lblNumError.Name = "lblNumError";
            this.lblNumError.Size = new System.Drawing.Size(379, 33);
            this.lblNumError.TabIndex = 0;
            this.lblNumError.Text = "商品数量非数值型，添加失败";
            // 
            // NumError
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(567, 119);
            this.Controls.Add(this.lblNumError);
            this.Name = "NumError";
            this.Text = "警告";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNumError;
    }
}