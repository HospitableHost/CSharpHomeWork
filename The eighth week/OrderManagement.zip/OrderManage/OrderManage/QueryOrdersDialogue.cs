﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OrderManagement;
namespace OrderManage
{
    public partial class QueryOrdersDialogue : Form
    {
        public event Action Back;
        public event Action<List<Order>> QuerySucess;
        public QueryOrdersDialogue()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            Back();
        }

        private void btnQuery_Click(object sender, EventArgs e)
        {
            if (OrderService.orders.Count == 0)
            {
                new HaveNoOrdersError().ShowDialog();
                return;
            }
            List<Order> os = new List<Order>();
            switch (cmbWhichKind.SelectedIndex)
            {
                case 0:
                    os=OrderService.SearchOrder(txtInfo.Text).ToList();
                    break;
                case 1:
                    try
                    {
                       Order o = OrderService.SearchOrder(int.Parse(txtInfo.Text));
                       os.Add(o);
                    }
                    catch
                    {
                        new OrderIdError().ShowDialog();
                        return;
                    }
                    break;
                case 2:
                    os = OrderService.SearchOrderByGoodsName(txtInfo.Text).ToList();
                    break;
            }
            QuerySucess(os);
        }

        private void QueryOrdersDialogue_Load(object sender, EventArgs e)
        {
            cmbWhichKind.SelectedIndex=0;
        }
    }
}
