﻿namespace OrderManage
{
    partial class DeleteOrderDialogue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.cmbChosenOrder = new System.Windows.Forms.ComboBox();
            this.dbsOrders = new System.Windows.Forms.BindingSource(this.components);
            this.lblChosenOrder = new System.Windows.Forms.Label();
            this.btnDelete = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dbsOrders)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbChosenOrder
            // 
            this.cmbChosenOrder.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbChosenOrder.DataSource = this.dbsOrders;
            this.cmbChosenOrder.DisplayMember = "Orderid";
            this.cmbChosenOrder.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbChosenOrder.FormattingEnabled = true;
            this.cmbChosenOrder.Location = new System.Drawing.Point(328, 45);
            this.cmbChosenOrder.Name = "cmbChosenOrder";
            this.cmbChosenOrder.Size = new System.Drawing.Size(132, 23);
            this.cmbChosenOrder.TabIndex = 0;
            // 
            // dbsOrders
            // 
            this.dbsOrders.DataSource = typeof(OrderManagement.Order);
            // 
            // lblChosenOrder
            // 
            this.lblChosenOrder.AutoSize = true;
            this.lblChosenOrder.Location = new System.Drawing.Point(28, 48);
            this.lblChosenOrder.Name = "lblChosenOrder";
            this.lblChosenOrder.Size = new System.Drawing.Size(232, 15);
            this.lblChosenOrder.TabIndex = 1;
            this.lblChosenOrder.Text = "选择所要删除的订单（订单号）：";
            // 
            // btnDelete
            // 
            this.btnDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDelete.Location = new System.Drawing.Point(328, 112);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(132, 47);
            this.btnDelete.TabIndex = 2;
            this.btnDelete.Text = "删除";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // DeleteOrderDialogue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(481, 183);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.lblChosenOrder);
            this.Controls.Add(this.cmbChosenOrder);
            this.Name = "DeleteOrderDialogue";
            this.Text = "删除订单";
            this.Load += new System.EventHandler(this.DeleteOrderDialogue_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dbsOrders)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbChosenOrder;
        private System.Windows.Forms.Label lblChosenOrder;
        private System.Windows.Forms.BindingSource dbsOrders;
        private System.Windows.Forms.Button btnDelete;
    }
}