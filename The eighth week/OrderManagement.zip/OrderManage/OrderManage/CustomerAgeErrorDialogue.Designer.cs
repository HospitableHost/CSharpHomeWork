﻿namespace OrderManage
{
    partial class CustomerAgeErrorDialogue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblAgeError1 = new System.Windows.Forms.Label();
            this.lblAgeError2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblAgeError1
            // 
            this.lblAgeError1.AutoSize = true;
            this.lblAgeError1.Font = new System.Drawing.Font("李旭科书法", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblAgeError1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblAgeError1.Location = new System.Drawing.Point(32, 26);
            this.lblAgeError1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAgeError1.Name = "lblAgeError1";
            this.lblAgeError1.Size = new System.Drawing.Size(247, 30);
            this.lblAgeError1.TabIndex = 0;
            this.lblAgeError1.Text = "顾客年龄非正确格式";
            // 
            // lblAgeError2
            // 
            this.lblAgeError2.AutoSize = true;
            this.lblAgeError2.Font = new System.Drawing.Font("李旭科书法", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblAgeError2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblAgeError2.Location = new System.Drawing.Point(32, 77);
            this.lblAgeError2.Name = "lblAgeError2";
            this.lblAgeError2.Size = new System.Drawing.Size(247, 30);
            this.lblAgeError2.TabIndex = 1;
            this.lblAgeError2.Text = "请重新输入顾客年龄";
            // 
            // CustomerAgeErrorDialogue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(312, 134);
            this.Controls.Add(this.lblAgeError2);
            this.Controls.Add(this.lblAgeError1);
            this.Font = new System.Drawing.Font("宋体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "CustomerAgeErrorDialogue";
            this.Text = "警告";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblAgeError1;
        private System.Windows.Forms.Label lblAgeError2;
    }
}