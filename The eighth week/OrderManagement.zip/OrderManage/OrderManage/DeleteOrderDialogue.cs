﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OrderManagement;
namespace OrderManage
{
    public partial class DeleteOrderDialogue : Form
    {
        public event Action deleteSuccess;
        public DeleteOrderDialogue()
        {
            InitializeComponent();
            dbsOrders.DataSource = OrderService.orders;

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if(OrderService.orders.Count == 0)
            {
                new HaveNoOrdersError().ShowDialog();
                return;
            }
            OrderService.DeleteOrder((cmbChosenOrder.SelectedItem as Order).Orderid);
            deleteSuccess();
            new ModifyCustomerSuccess().ShowDialog();
        }

        private void DeleteOrderDialogue_Load(object sender, EventArgs e)
        {
            if (OrderService.orders.Count != 0)
                cmbChosenOrder.SelectedIndex = 0;
        }
    }
}
