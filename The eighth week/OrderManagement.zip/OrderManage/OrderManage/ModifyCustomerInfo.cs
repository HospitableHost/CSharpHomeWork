﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OrderManagement;

namespace OrderManage
{
    public partial class ModifyCustomerInfo : Form
    {
        public ModifyCustomerInfo()
        {
            InitializeComponent();
            bdsCustomers.DataSource = CustomerManagement.customers;
        }

        private void cmbChooseCustomer_SelectedIndexChanged(object sender, EventArgs e)
        {
            Customer customer = cmbChooseCustomer.SelectedItem as Customer;
            txtCustomerName.Text = customer.Name;
            txtCustomerGender.Text = customer.Gender;
            txtCustomerAge.Text = customer.Age.ToString();
            txtCustomerAddress.Text = customer.Address;
            txtCustomerPhone.Text = customer.PhoneNum;
        }

        private void btnModifyCustomerInfo_Click(object sender, EventArgs e)
        {
            try
            {

                Customer customer = cmbChooseCustomer.SelectedItem as Customer;
                customer.Name = txtCustomerName.Text;
                customer.Address = txtCustomerAddress.Text;
                customer.Age = int.Parse(txtCustomerAge.Text);
                customer.Gender = txtCustomerGender.Text;
                customer.PhoneNum = txtCustomerPhone.Text;
                ModifyCustomerSuccess modifyCustomerSuccess = new ModifyCustomerSuccess();
                modifyCustomerSuccess.ShowDialog();
            }
            catch
            {
                
                CustomerAgeErrorDialogue customerAgeErrorDialogue = new CustomerAgeErrorDialogue();
                customerAgeErrorDialogue.ShowDialog();
            }

        }
    }
}
