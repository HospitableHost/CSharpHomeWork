﻿namespace OrderManage
{
    partial class ModifyGoodsInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Button btnModifyGoodsInfo;
            this.lblChosenGoods = new System.Windows.Forms.Label();
            this.cmbChooseGoods = new System.Windows.Forms.ComboBox();
            this.bdsGoods = new System.Windows.Forms.BindingSource(this.components);
            this.gbxGoodsInfo = new System.Windows.Forms.GroupBox();
            this.txtGoodsPrice = new System.Windows.Forms.TextBox();
            this.txtGoodsName = new System.Windows.Forms.TextBox();
            this.lblGoodsPrice = new System.Windows.Forms.Label();
            this.lblGoodsName = new System.Windows.Forms.Label();
            btnModifyGoodsInfo = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.bdsGoods)).BeginInit();
            this.gbxGoodsInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnModifyGoodsInfo
            // 
            btnModifyGoodsInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            btnModifyGoodsInfo.Location = new System.Drawing.Point(413, 19);
            btnModifyGoodsInfo.Name = "btnModifyGoodsInfo";
            btnModifyGoodsInfo.Size = new System.Drawing.Size(118, 33);
            btnModifyGoodsInfo.TabIndex = 2;
            btnModifyGoodsInfo.Text = "修改";
            btnModifyGoodsInfo.UseVisualStyleBackColor = true;
            btnModifyGoodsInfo.Click += new System.EventHandler(this.btnModifyGoodsInfo_Click);
            // 
            // lblChosenGoods
            // 
            this.lblChosenGoods.AutoSize = true;
            this.lblChosenGoods.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblChosenGoods.Location = new System.Drawing.Point(12, 24);
            this.lblChosenGoods.Name = "lblChosenGoods";
            this.lblChosenGoods.Size = new System.Drawing.Size(189, 20);
            this.lblChosenGoods.TabIndex = 0;
            this.lblChosenGoods.Text = "选择要修改的商品：";
            // 
            // cmbChooseGoods
            // 
            this.cmbChooseGoods.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbChooseGoods.DataSource = this.bdsGoods;
            this.cmbChooseGoods.DisplayMember = "Name";
            this.cmbChooseGoods.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbChooseGoods.FormattingEnabled = true;
            this.cmbChooseGoods.Location = new System.Drawing.Point(204, 24);
            this.cmbChooseGoods.Name = "cmbChooseGoods";
            this.cmbChooseGoods.Size = new System.Drawing.Size(189, 23);
            this.cmbChooseGoods.TabIndex = 1;
            this.cmbChooseGoods.SelectedIndexChanged += new System.EventHandler(this.cmbChooseGoods_SelectedIndexChanged);
            // 
            // bdsGoods
            // 
            this.bdsGoods.DataSource = typeof(OrderManagement.Goods);
            // 
            // gbxGoodsInfo
            // 
            this.gbxGoodsInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbxGoodsInfo.Controls.Add(this.txtGoodsPrice);
            this.gbxGoodsInfo.Controls.Add(this.txtGoodsName);
            this.gbxGoodsInfo.Controls.Add(this.lblGoodsPrice);
            this.gbxGoodsInfo.Controls.Add(this.lblGoodsName);
            this.gbxGoodsInfo.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.gbxGoodsInfo.Location = new System.Drawing.Point(16, 76);
            this.gbxGoodsInfo.Name = "gbxGoodsInfo";
            this.gbxGoodsInfo.Size = new System.Drawing.Size(515, 174);
            this.gbxGoodsInfo.TabIndex = 3;
            this.gbxGoodsInfo.TabStop = false;
            this.gbxGoodsInfo.Text = "商品信息";
            // 
            // txtGoodsPrice
            // 
            this.txtGoodsPrice.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtGoodsPrice.Location = new System.Drawing.Point(147, 112);
            this.txtGoodsPrice.Name = "txtGoodsPrice";
            this.txtGoodsPrice.Size = new System.Drawing.Size(346, 30);
            this.txtGoodsPrice.TabIndex = 3;
            // 
            // txtGoodsName
            // 
            this.txtGoodsName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtGoodsName.Location = new System.Drawing.Point(147, 53);
            this.txtGoodsName.Name = "txtGoodsName";
            this.txtGoodsName.Size = new System.Drawing.Size(346, 30);
            this.txtGoodsName.TabIndex = 2;
            // 
            // lblGoodsPrice
            // 
            this.lblGoodsPrice.AutoSize = true;
            this.lblGoodsPrice.Location = new System.Drawing.Point(19, 117);
            this.lblGoodsPrice.Name = "lblGoodsPrice";
            this.lblGoodsPrice.Size = new System.Drawing.Size(89, 20);
            this.lblGoodsPrice.TabIndex = 1;
            this.lblGoodsPrice.Text = "商品价格";
            // 
            // lblGoodsName
            // 
            this.lblGoodsName.AutoSize = true;
            this.lblGoodsName.Location = new System.Drawing.Point(19, 59);
            this.lblGoodsName.Name = "lblGoodsName";
            this.lblGoodsName.Size = new System.Drawing.Size(89, 20);
            this.lblGoodsName.TabIndex = 0;
            this.lblGoodsName.Text = "商品名称";
            // 
            // ModifyGoodsInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(543, 262);
            this.Controls.Add(this.gbxGoodsInfo);
            this.Controls.Add(btnModifyGoodsInfo);
            this.Controls.Add(this.cmbChooseGoods);
            this.Controls.Add(this.lblChosenGoods);
            this.Name = "ModifyGoodsInfo";
            this.Text = "修改商品信息";
            ((System.ComponentModel.ISupportInitialize)(this.bdsGoods)).EndInit();
            this.gbxGoodsInfo.ResumeLayout(false);
            this.gbxGoodsInfo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblChosenGoods;
        private System.Windows.Forms.ComboBox cmbChooseGoods;
        private System.Windows.Forms.GroupBox gbxGoodsInfo;
        private System.Windows.Forms.TextBox txtGoodsPrice;
        private System.Windows.Forms.TextBox txtGoodsName;
        private System.Windows.Forms.Label lblGoodsPrice;
        private System.Windows.Forms.Label lblGoodsName;
        private System.Windows.Forms.BindingSource bdsGoods;
    }
}