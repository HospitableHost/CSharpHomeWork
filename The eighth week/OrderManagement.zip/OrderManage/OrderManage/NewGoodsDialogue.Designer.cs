﻿namespace OrderManage
{
    partial class NewGoodsDialogue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnNewGoods = new System.Windows.Forms.Button();
            this.grpGoodsInfo = new System.Windows.Forms.GroupBox();
            this.lblGoodsName = new System.Windows.Forms.Label();
            this.lblGoodsPrice = new System.Windows.Forms.Label();
            this.txtGoodsName = new System.Windows.Forms.TextBox();
            this.txtGoodsPrice = new System.Windows.Forms.TextBox();
            this.grpGoodsInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnNewGoods
            // 
            this.btnNewGoods.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNewGoods.Location = new System.Drawing.Point(289, 195);
            this.btnNewGoods.Name = "btnNewGoods";
            this.btnNewGoods.Size = new System.Drawing.Size(120, 41);
            this.btnNewGoods.TabIndex = 0;
            this.btnNewGoods.Text = "新增商品";
            this.btnNewGoods.UseVisualStyleBackColor = true;
            this.btnNewGoods.Click += new System.EventHandler(this.btnNewGoods_Click);
            // 
            // grpGoodsInfo
            // 
            this.grpGoodsInfo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grpGoodsInfo.Controls.Add(this.txtGoodsPrice);
            this.grpGoodsInfo.Controls.Add(this.txtGoodsName);
            this.grpGoodsInfo.Controls.Add(this.lblGoodsPrice);
            this.grpGoodsInfo.Controls.Add(this.lblGoodsName);
            this.grpGoodsInfo.Location = new System.Drawing.Point(12, 12);
            this.grpGoodsInfo.Name = "grpGoodsInfo";
            this.grpGoodsInfo.Size = new System.Drawing.Size(397, 168);
            this.grpGoodsInfo.TabIndex = 1;
            this.grpGoodsInfo.TabStop = false;
            this.grpGoodsInfo.Text = "商品信息";
            // 
            // lblGoodsName
            // 
            this.lblGoodsName.AutoSize = true;
            this.lblGoodsName.Location = new System.Drawing.Point(18, 47);
            this.lblGoodsName.Name = "lblGoodsName";
            this.lblGoodsName.Size = new System.Drawing.Size(67, 15);
            this.lblGoodsName.TabIndex = 0;
            this.lblGoodsName.Text = "商品名称";
            // 
            // lblGoodsPrice
            // 
            this.lblGoodsPrice.AutoSize = true;
            this.lblGoodsPrice.Location = new System.Drawing.Point(18, 107);
            this.lblGoodsPrice.Name = "lblGoodsPrice";
            this.lblGoodsPrice.Size = new System.Drawing.Size(67, 15);
            this.lblGoodsPrice.TabIndex = 1;
            this.lblGoodsPrice.Text = "商品价格";
            // 
            // txtGoodsName
            // 
            this.txtGoodsName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtGoodsName.Location = new System.Drawing.Point(103, 41);
            this.txtGoodsName.Name = "txtGoodsName";
            this.txtGoodsName.Size = new System.Drawing.Size(272, 25);
            this.txtGoodsName.TabIndex = 2;
            // 
            // txtGoodsPrice
            // 
            this.txtGoodsPrice.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtGoodsPrice.Location = new System.Drawing.Point(103, 101);
            this.txtGoodsPrice.Name = "txtGoodsPrice";
            this.txtGoodsPrice.Size = new System.Drawing.Size(272, 25);
            this.txtGoodsPrice.TabIndex = 3;
            // 
            // NewGoodsDialogue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(421, 247);
            this.Controls.Add(this.grpGoodsInfo);
            this.Controls.Add(this.btnNewGoods);
            this.Name = "NewGoodsDialogue";
            this.Text = "新增商品";
            this.grpGoodsInfo.ResumeLayout(false);
            this.grpGoodsInfo.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnNewGoods;
        private System.Windows.Forms.GroupBox grpGoodsInfo;
        private System.Windows.Forms.TextBox txtGoodsPrice;
        private System.Windows.Forms.TextBox txtGoodsName;
        private System.Windows.Forms.Label lblGoodsPrice;
        private System.Windows.Forms.Label lblGoodsName;
    }
}