﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OrderManagement;
namespace OrderManage
{
    public partial class ModifyOrderDialogue : Form
    {
        public event Action ModifySuccess;
        public ModifyOrderDialogue()
        {
            InitializeComponent();
            bdsCustomers.DataSource = CustomerManagement.customers;
            bdsGoods.DataSource = GoodsManagement.goods;
            bdsOrders.DataSource = OrderService.orders;
        }

        private void ModifyOrderDialogue_Load(object sender, EventArgs e)
        {
            if (OrderService.orders.Count != 0)
                cmbChosenOrder.SelectedIndex = 0;
            if (CustomerManagement.customers.Count != 0)
                cmbCustomer.SelectedIndex = 0;
        }

        private void cmbChosenOrder_SelectedIndexChanged(object sender, EventArgs e)
        {
            bdsItems.DataSource = (cmbChosenOrder.SelectedItem as Order).Orderitem;
            bdsItems.ResetBindings(false);
        }

        private void btnModify_Click(object sender, EventArgs e)
        {
            if (OrderService.orders.Count == 0)
            {
                new HaveNoOrdersError().ShowDialog();
                return;
            }
            if(cmbItem.Items.Count!=0&&cmbGoods.Items.Count!=0)
            {
                (cmbItem.SelectedItem as OrderItem).goods = cmbGoods.SelectedItem as Goods;
                (cmbItem.SelectedItem as OrderItem).GoodsName = (cmbGoods.SelectedItem as Goods).Name;
                try
                {
                    (cmbItem.SelectedItem as OrderItem).quantity = double.Parse(txtGoodsNum.Text);
                    (cmbChosenOrder.SelectedItem as Order).TotalPrice = (cmbChosenOrder.SelectedItem as Order).CalculateTotalprice();
                    (cmbChosenOrder.SelectedItem as Order).Total_Price = (cmbChosenOrder.SelectedItem as Order).TotalPrice;
                }
                catch
                {
                    new NewGoodsPriceError().ShowDialog();
                    return;
                }
            }
            if (CustomerManagement.customers.Count != 0)
            {
                (cmbChosenOrder.SelectedItem as Order).customer = (cmbCustomer.SelectedItem as Customer);
                (cmbChosenOrder.SelectedItem as Order).Customer_Name = (cmbCustomer.SelectedItem as Customer).Name;
            }

            if (CustomerManagement.customers.Count == 0 && !(cmbItem.Items.Count != 0 && cmbGoods.Items.Count != 0))
                new ModifyNothingError().ShowDialog();
            else
            {
                ModifySuccess();
                new ModifyCustomerSuccess().ShowDialog();
            }
        }

        private void cmbItem_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtGoodsNum.Text = (cmbItem.SelectedItem as OrderItem).quantity.ToString();
        }
    }
}
