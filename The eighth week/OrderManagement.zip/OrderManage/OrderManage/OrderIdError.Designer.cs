﻿namespace OrderManage
{
    partial class OrderIdError
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblOrderIdError = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblOrderIdError
            // 
            this.lblOrderIdError.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblOrderIdError.AutoSize = true;
            this.lblOrderIdError.Font = new System.Drawing.Font("李旭科书法", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblOrderIdError.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblOrderIdError.Location = new System.Drawing.Point(62, 58);
            this.lblOrderIdError.Name = "lblOrderIdError";
            this.lblOrderIdError.Size = new System.Drawing.Size(351, 33);
            this.lblOrderIdError.TabIndex = 0;
            this.lblOrderIdError.Text = "订单号非数值型，添加失败";
            // 
            // OrderIdError
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(480, 146);
            this.Controls.Add(this.lblOrderIdError);
            this.Name = "OrderIdError";
            this.Text = "警告";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblOrderIdError;
    }
}