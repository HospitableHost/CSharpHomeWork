﻿namespace OrderManage
{
    partial class QueryOrdersDialogue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblWhichKind = new System.Windows.Forms.Label();
            this.cmbWhichKind = new System.Windows.Forms.ComboBox();
            this.lblInfo = new System.Windows.Forms.Label();
            this.txtInfo = new System.Windows.Forms.TextBox();
            this.btnQuery = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblWhichKind
            // 
            this.lblWhichKind.AutoSize = true;
            this.lblWhichKind.Location = new System.Drawing.Point(47, 48);
            this.lblWhichKind.Name = "lblWhichKind";
            this.lblWhichKind.Size = new System.Drawing.Size(150, 15);
            this.lblWhichKind.TabIndex = 0;
            this.lblWhichKind.Text = "选择以何种方式查询:";
            // 
            // cmbWhichKind
            // 
            this.cmbWhichKind.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbWhichKind.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbWhichKind.FormattingEnabled = true;
            this.cmbWhichKind.Items.AddRange(new object[] {
            "按照顾客名查找",
            "按照订单号查找",
            "按照包含的商品名查找"});
            this.cmbWhichKind.Location = new System.Drawing.Point(251, 43);
            this.cmbWhichKind.Name = "cmbWhichKind";
            this.cmbWhichKind.Size = new System.Drawing.Size(372, 23);
            this.cmbWhichKind.TabIndex = 1;
            // 
            // lblInfo
            // 
            this.lblInfo.AutoSize = true;
            this.lblInfo.Location = new System.Drawing.Point(47, 108);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(127, 15);
            this.lblInfo.TabIndex = 2;
            this.lblInfo.Text = "请输入查找信息：";
            // 
            // txtInfo
            // 
            this.txtInfo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtInfo.Location = new System.Drawing.Point(251, 103);
            this.txtInfo.Name = "txtInfo";
            this.txtInfo.Size = new System.Drawing.Size(372, 25);
            this.txtInfo.TabIndex = 3;
            // 
            // btnQuery
            // 
            this.btnQuery.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.btnQuery.Location = new System.Drawing.Point(367, 178);
            this.btnQuery.Name = "btnQuery";
            this.btnQuery.Size = new System.Drawing.Size(256, 38);
            this.btnQuery.TabIndex = 4;
            this.btnQuery.Text = "查找订单";
            this.btnQuery.UseVisualStyleBackColor = true;
            this.btnQuery.Click += new System.EventHandler(this.btnQuery_Click);
            // 
            // btnBack
            // 
            this.btnBack.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBack.Location = new System.Drawing.Point(367, 236);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(256, 39);
            this.btnBack.TabIndex = 5;
            this.btnBack.Text = "显示全部订单";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // QueryOrdersDialogue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(672, 298);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnQuery);
            this.Controls.Add(this.txtInfo);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.cmbWhichKind);
            this.Controls.Add(this.lblWhichKind);
            this.Name = "QueryOrdersDialogue";
            this.Text = "查询订单";
            this.Load += new System.EventHandler(this.QueryOrdersDialogue_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblWhichKind;
        private System.Windows.Forms.ComboBox cmbWhichKind;
        private System.Windows.Forms.Label lblInfo;
        private System.Windows.Forms.TextBox txtInfo;
        private System.Windows.Forms.Button btnQuery;
        private System.Windows.Forms.Button btnBack;
    }
}