﻿namespace OrderManage
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.mnsOrderManage = new System.Windows.Forms.MenuStrip();
            this.管理订单ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.新建订单ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.修改订单ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.删除订单ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.查询订单ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.文件ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.导入订单ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.导出订单ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.顾客ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.新增顾客信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.修改顾客信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.商品ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.新增商品信息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.修改商品ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dgvItems = new System.Windows.Forms.DataGridView();
            this.odlgOrdersXML = new System.Windows.Forms.OpenFileDialog();
            this.sdlgSaveOrders = new System.Windows.Forms.SaveFileDialog();
            this.dgvOrders = new System.Windows.Forms.DataGridView();
            this.bdsItems = new System.Windows.Forms.BindingSource(this.components);
            this.orderidDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.createTimeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.totalPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bdsOrders = new System.Windows.Forms.BindingSource(this.components);
            this.goodsNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.quantity_ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mnsOrderManage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItems)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrders)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsItems)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsOrders)).BeginInit();
            this.SuspendLayout();
            // 
            // mnsOrderManage
            // 
            this.mnsOrderManage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.mnsOrderManage.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.mnsOrderManage.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.管理订单ToolStripMenuItem,
            this.文件ToolStripMenuItem,
            this.顾客ToolStripMenuItem,
            this.商品ToolStripMenuItem});
            this.mnsOrderManage.Location = new System.Drawing.Point(0, 0);
            this.mnsOrderManage.Name = "mnsOrderManage";
            this.mnsOrderManage.Size = new System.Drawing.Size(883, 28);
            this.mnsOrderManage.TabIndex = 0;
            this.mnsOrderManage.Text = "menuStrip1";
            // 
            // 管理订单ToolStripMenuItem
            // 
            this.管理订单ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.新建订单ToolStripMenuItem,
            this.修改订单ToolStripMenuItem,
            this.删除订单ToolStripMenuItem,
            this.查询订单ToolStripMenuItem});
            this.管理订单ToolStripMenuItem.Name = "管理订单ToolStripMenuItem";
            this.管理订单ToolStripMenuItem.Size = new System.Drawing.Size(51, 24);
            this.管理订单ToolStripMenuItem.Text = "订单";
            // 
            // 新建订单ToolStripMenuItem
            // 
            this.新建订单ToolStripMenuItem.Name = "新建订单ToolStripMenuItem";
            this.新建订单ToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.新建订单ToolStripMenuItem.Text = "新建订单";
            this.新建订单ToolStripMenuItem.Click += new System.EventHandler(this.新建订单ToolStripMenuItem_Click);
            // 
            // 修改订单ToolStripMenuItem
            // 
            this.修改订单ToolStripMenuItem.Name = "修改订单ToolStripMenuItem";
            this.修改订单ToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.修改订单ToolStripMenuItem.Text = "修改订单";
            this.修改订单ToolStripMenuItem.Click += new System.EventHandler(this.修改订单ToolStripMenuItem_Click);
            // 
            // 删除订单ToolStripMenuItem
            // 
            this.删除订单ToolStripMenuItem.Name = "删除订单ToolStripMenuItem";
            this.删除订单ToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.删除订单ToolStripMenuItem.Text = "删除订单";
            this.删除订单ToolStripMenuItem.Click += new System.EventHandler(this.删除订单ToolStripMenuItem_Click);
            // 
            // 查询订单ToolStripMenuItem
            // 
            this.查询订单ToolStripMenuItem.Name = "查询订单ToolStripMenuItem";
            this.查询订单ToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.查询订单ToolStripMenuItem.Text = "查询订单";
            this.查询订单ToolStripMenuItem.Click += new System.EventHandler(this.查询订单ToolStripMenuItem_Click);
            // 
            // 文件ToolStripMenuItem
            // 
            this.文件ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.导入订单ToolStripMenuItem,
            this.导出订单ToolStripMenuItem});
            this.文件ToolStripMenuItem.Name = "文件ToolStripMenuItem";
            this.文件ToolStripMenuItem.Size = new System.Drawing.Size(51, 24);
            this.文件ToolStripMenuItem.Text = "文件";
            // 
            // 导入订单ToolStripMenuItem
            // 
            this.导入订单ToolStripMenuItem.Name = "导入订单ToolStripMenuItem";
            this.导入订单ToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.导入订单ToolStripMenuItem.Text = "导入订单";
            this.导入订单ToolStripMenuItem.Click += new System.EventHandler(this.导入订单ToolStripMenuItem_Click);
            // 
            // 导出订单ToolStripMenuItem
            // 
            this.导出订单ToolStripMenuItem.Name = "导出订单ToolStripMenuItem";
            this.导出订单ToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.导出订单ToolStripMenuItem.Text = "导出订单";
            this.导出订单ToolStripMenuItem.Click += new System.EventHandler(this.导出订单ToolStripMenuItem_Click);
            // 
            // 顾客ToolStripMenuItem
            // 
            this.顾客ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.新增顾客信息ToolStripMenuItem,
            this.修改顾客信息ToolStripMenuItem});
            this.顾客ToolStripMenuItem.Name = "顾客ToolStripMenuItem";
            this.顾客ToolStripMenuItem.Size = new System.Drawing.Size(51, 24);
            this.顾客ToolStripMenuItem.Text = "顾客";
            // 
            // 新增顾客信息ToolStripMenuItem
            // 
            this.新增顾客信息ToolStripMenuItem.Name = "新增顾客信息ToolStripMenuItem";
            this.新增顾客信息ToolStripMenuItem.Size = new System.Drawing.Size(174, 26);
            this.新增顾客信息ToolStripMenuItem.Text = "新增顾客信息";
            this.新增顾客信息ToolStripMenuItem.Click += new System.EventHandler(this.新增顾客信息ToolStripMenuItem_Click);
            // 
            // 修改顾客信息ToolStripMenuItem
            // 
            this.修改顾客信息ToolStripMenuItem.Name = "修改顾客信息ToolStripMenuItem";
            this.修改顾客信息ToolStripMenuItem.Size = new System.Drawing.Size(174, 26);
            this.修改顾客信息ToolStripMenuItem.Text = "修改顾客信息";
            this.修改顾客信息ToolStripMenuItem.Click += new System.EventHandler(this.修改顾客信息ToolStripMenuItem_Click);
            // 
            // 商品ToolStripMenuItem
            // 
            this.商品ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.新增商品信息ToolStripMenuItem,
            this.修改商品ToolStripMenuItem});
            this.商品ToolStripMenuItem.Name = "商品ToolStripMenuItem";
            this.商品ToolStripMenuItem.Size = new System.Drawing.Size(51, 24);
            this.商品ToolStripMenuItem.Text = "商品";
            // 
            // 新增商品信息ToolStripMenuItem
            // 
            this.新增商品信息ToolStripMenuItem.Name = "新增商品信息ToolStripMenuItem";
            this.新增商品信息ToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.新增商品信息ToolStripMenuItem.Text = "新增商品";
            this.新增商品信息ToolStripMenuItem.Click += new System.EventHandler(this.新增商品信息ToolStripMenuItem_Click);
            // 
            // 修改商品ToolStripMenuItem
            // 
            this.修改商品ToolStripMenuItem.Name = "修改商品ToolStripMenuItem";
            this.修改商品ToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.修改商品ToolStripMenuItem.Text = "修改商品";
            this.修改商品ToolStripMenuItem.Click += new System.EventHandler(this.修改商品ToolStripMenuItem_Click);
            // 
            // dgvItems
            // 
            this.dgvItems.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvItems.AutoGenerateColumns = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvItems.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvItems.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvItems.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.goodsNameDataGridViewTextBoxColumn,
            this.quantity_});
            this.dgvItems.DataSource = this.bdsItems;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvItems.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvItems.Location = new System.Drawing.Point(631, 31);
            this.dgvItems.Name = "dgvItems";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvItems.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvItems.RowTemplate.Height = 27;
            this.dgvItems.Size = new System.Drawing.Size(240, 361);
            this.dgvItems.TabIndex = 2;
            // 
            // odlgOrdersXML
            // 
            this.odlgOrdersXML.FileName = "openFileDialog1";
            // 
            // dgvOrders
            // 
            this.dgvOrders.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.dgvOrders.AutoGenerateColumns = false;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvOrders.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvOrders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOrders.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.orderidDataGridViewTextBoxColumn,
            this.createTimeDataGridViewTextBoxColumn,
            this.customerNameDataGridViewTextBoxColumn,
            this.totalPriceDataGridViewTextBoxColumn});
            this.dgvOrders.DataSource = this.bdsOrders;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvOrders.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgvOrders.Location = new System.Drawing.Point(12, 31);
            this.dgvOrders.Name = "dgvOrders";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvOrders.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvOrders.RowTemplate.Height = 27;
            this.dgvOrders.Size = new System.Drawing.Size(613, 361);
            this.dgvOrders.TabIndex = 3;
            // 
            // bdsItems
            // 
            this.bdsItems.DataMember = "Items";
            this.bdsItems.DataSource = this.bdsOrders;
            // 
            // orderidDataGridViewTextBoxColumn
            // 
            this.orderidDataGridViewTextBoxColumn.DataPropertyName = "Orderid";
            this.orderidDataGridViewTextBoxColumn.HeaderText = "订单号";
            this.orderidDataGridViewTextBoxColumn.Name = "orderidDataGridViewTextBoxColumn";
            this.orderidDataGridViewTextBoxColumn.Width = 150;
            // 
            // createTimeDataGridViewTextBoxColumn
            // 
            this.createTimeDataGridViewTextBoxColumn.DataPropertyName = "Create_Time";
            this.createTimeDataGridViewTextBoxColumn.HeaderText = "创建时间";
            this.createTimeDataGridViewTextBoxColumn.Name = "createTimeDataGridViewTextBoxColumn";
            this.createTimeDataGridViewTextBoxColumn.Width = 150;
            // 
            // customerNameDataGridViewTextBoxColumn
            // 
            this.customerNameDataGridViewTextBoxColumn.DataPropertyName = "Customer_Name";
            this.customerNameDataGridViewTextBoxColumn.HeaderText = "顾客姓名";
            this.customerNameDataGridViewTextBoxColumn.Name = "customerNameDataGridViewTextBoxColumn";
            this.customerNameDataGridViewTextBoxColumn.ReadOnly = true;
            this.customerNameDataGridViewTextBoxColumn.Width = 150;
            // 
            // totalPriceDataGridViewTextBoxColumn
            // 
            this.totalPriceDataGridViewTextBoxColumn.DataPropertyName = "Total_Price";
            this.totalPriceDataGridViewTextBoxColumn.HeaderText = "订单总价";
            this.totalPriceDataGridViewTextBoxColumn.Name = "totalPriceDataGridViewTextBoxColumn";
            this.totalPriceDataGridViewTextBoxColumn.ReadOnly = true;
            this.totalPriceDataGridViewTextBoxColumn.Width = 120;
            // 
            // bdsOrders
            // 
            this.bdsOrders.DataSource = typeof(OrderManagement.Order);
            // 
            // goodsNameDataGridViewTextBoxColumn
            // 
            this.goodsNameDataGridViewTextBoxColumn.DataPropertyName = "GoodsName";
            this.goodsNameDataGridViewTextBoxColumn.HeaderText = "商品名";
            this.goodsNameDataGridViewTextBoxColumn.Name = "goodsNameDataGridViewTextBoxColumn";
            this.goodsNameDataGridViewTextBoxColumn.Width = 200;
            // 
            // quantity_
            // 
            this.quantity_.DataPropertyName = "quantity_";
            this.quantity_.HeaderText = "数量";
            this.quantity_.Name = "quantity_";
            this.quantity_.ReadOnly = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(883, 402);
            this.Controls.Add(this.dgvOrders);
            this.Controls.Add(this.dgvItems);
            this.Controls.Add(this.mnsOrderManage);
            this.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.MainMenuStrip = this.mnsOrderManage;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Form1";
            this.Text = "订单管理程序";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.mnsOrderManage.ResumeLayout(false);
            this.mnsOrderManage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvItems)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrders)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsItems)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsOrders)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnsOrderManage;
        private System.Windows.Forms.ToolStripMenuItem 管理订单ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 新建订单ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 修改订单ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 删除订单ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 文件ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 导入订单ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 导出订单ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 查询订单ToolStripMenuItem;
        private System.Windows.Forms.DataGridView dgvItems;
        private System.Windows.Forms.ToolStripMenuItem 顾客ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 新增顾客信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 修改顾客信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 商品ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 新增商品信息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 修改商品ToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog odlgOrdersXML;
        private System.Windows.Forms.SaveFileDialog sdlgSaveOrders;
        private System.Windows.Forms.DataGridView dgvOrders;
        private System.Windows.Forms.BindingSource bdsOrders;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderidDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn createTimeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn totalPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource bdsItems;
        private System.Windows.Forms.DataGridViewTextBoxColumn goodsNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn quantity_;
    }
}

