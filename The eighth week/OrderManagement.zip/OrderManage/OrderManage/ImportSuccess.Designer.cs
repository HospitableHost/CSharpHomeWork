﻿namespace OrderManage
{
    partial class ImportSuccess
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblImportSuccess = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblImportSuccess
            // 
            this.lblImportSuccess.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblImportSuccess.AutoSize = true;
            this.lblImportSuccess.Font = new System.Drawing.Font("李旭科书法", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblImportSuccess.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblImportSuccess.Location = new System.Drawing.Point(53, 38);
            this.lblImportSuccess.Name = "lblImportSuccess";
            this.lblImportSuccess.Size = new System.Drawing.Size(183, 33);
            this.lblImportSuccess.TabIndex = 0;
            this.lblImportSuccess.Text = "订单导入成功";
            // 
            // ImportSuccess
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(284, 115);
            this.Controls.Add(this.lblImportSuccess);
            this.Name = "ImportSuccess";
            this.Text = "对话框";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblImportSuccess;
    }
}