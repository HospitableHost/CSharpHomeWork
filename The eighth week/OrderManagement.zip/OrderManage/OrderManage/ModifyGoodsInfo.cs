﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OrderManagement;
namespace OrderManage
{
    public partial class ModifyGoodsInfo : Form
    {
        public ModifyGoodsInfo()
        {
            InitializeComponent();
            bdsGoods.DataSource = GoodsManagement.goods;
        }

        private void cmbChooseGoods_SelectedIndexChanged(object sender, EventArgs e)
        {
            Goods goods = cmbChooseGoods.SelectedItem as Goods;
            txtGoodsName.Text = goods.Name;
            txtGoodsPrice.Text = goods.Price.ToString();
        }

        private void btnModifyGoodsInfo_Click(object sender, EventArgs e)
        {
            try
            {

                Goods goods = cmbChooseGoods.SelectedItem as Goods;
                goods.Name = txtGoodsName.Text;
                goods.Price = double.Parse(txtGoodsPrice.Text);
                ModifyCustomerSuccess modifyCustomerSuccess = new ModifyCustomerSuccess();
                modifyCustomerSuccess.ShowDialog();
            }
            catch
            {

                NewGoodsPriceError newGoodsPriceError = new NewGoodsPriceError();
                newGoodsPriceError.ShowDialog();
            }
        }
    }
}
