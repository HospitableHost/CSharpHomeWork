﻿namespace OrderManage
{
    partial class CustomerNullError
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCustomerNull = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblCustomerNull
            // 
            this.lblCustomerNull.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCustomerNull.AutoSize = true;
            this.lblCustomerNull.Font = new System.Drawing.Font("李旭科书法", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblCustomerNull.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblCustomerNull.Location = new System.Drawing.Point(71, 36);
            this.lblCustomerNull.Name = "lblCustomerNull";
            this.lblCustomerNull.Size = new System.Drawing.Size(267, 33);
            this.lblCustomerNull.TabIndex = 0;
            this.lblCustomerNull.Text = "顾客空白，添加失败";
            // 
            // CustomerNullError
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(414, 111);
            this.Controls.Add(this.lblCustomerNull);
            this.Name = "CustomerNullError";
            this.Text = "警告";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCustomerNull;
    }
}