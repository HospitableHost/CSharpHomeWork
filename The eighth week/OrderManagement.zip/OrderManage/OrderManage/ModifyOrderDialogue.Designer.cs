﻿namespace OrderManage
{
    partial class ModifyOrderDialogue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.cmbChosenOrder = new System.Windows.Forms.ComboBox();
            this.bdsOrders = new System.Windows.Forms.BindingSource(this.components);
            this.lblChosenOrder = new System.Windows.Forms.Label();
            this.lblModifyCustomer = new System.Windows.Forms.Label();
            this.cmbCustomer = new System.Windows.Forms.ComboBox();
            this.bdsCustomers = new System.Windows.Forms.BindingSource(this.components);
            this.btnModify = new System.Windows.Forms.Button();
            this.lblChosenItem = new System.Windows.Forms.Label();
            this.bdsItems = new System.Windows.Forms.BindingSource(this.components);
            this.cmbItem = new System.Windows.Forms.ComboBox();
            this.lblModifyGoods = new System.Windows.Forms.Label();
            this.bdsGoods = new System.Windows.Forms.BindingSource(this.components);
            this.cmbGoods = new System.Windows.Forms.ComboBox();
            this.lblModifyNum = new System.Windows.Forms.Label();
            this.txtGoodsNum = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.bdsOrders)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsCustomers)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsItems)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsGoods)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbChosenOrder
            // 
            this.cmbChosenOrder.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbChosenOrder.DataSource = this.bdsOrders;
            this.cmbChosenOrder.DisplayMember = "Orderid";
            this.cmbChosenOrder.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbChosenOrder.FormattingEnabled = true;
            this.cmbChosenOrder.Location = new System.Drawing.Point(293, 34);
            this.cmbChosenOrder.Name = "cmbChosenOrder";
            this.cmbChosenOrder.Size = new System.Drawing.Size(263, 23);
            this.cmbChosenOrder.TabIndex = 0;
            this.cmbChosenOrder.SelectedIndexChanged += new System.EventHandler(this.cmbChosenOrder_SelectedIndexChanged);
            // 
            // bdsOrders
            // 
            this.bdsOrders.DataSource = typeof(OrderManagement.Order);
            // 
            // lblChosenOrder
            // 
            this.lblChosenOrder.AutoSize = true;
            this.lblChosenOrder.Location = new System.Drawing.Point(28, 37);
            this.lblChosenOrder.Name = "lblChosenOrder";
            this.lblChosenOrder.Size = new System.Drawing.Size(172, 15);
            this.lblChosenOrder.TabIndex = 1;
            this.lblChosenOrder.Text = "选择所要修改的订单号：";
            // 
            // lblModifyCustomer
            // 
            this.lblModifyCustomer.AutoSize = true;
            this.lblModifyCustomer.Location = new System.Drawing.Point(28, 95);
            this.lblModifyCustomer.Name = "lblModifyCustomer";
            this.lblModifyCustomer.Size = new System.Drawing.Size(112, 15);
            this.lblModifyCustomer.TabIndex = 2;
            this.lblModifyCustomer.Text = "将顾客修改为：";
            // 
            // cmbCustomer
            // 
            this.cmbCustomer.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbCustomer.DataSource = this.bdsCustomers;
            this.cmbCustomer.DisplayMember = "Name";
            this.cmbCustomer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCustomer.FormattingEnabled = true;
            this.cmbCustomer.Location = new System.Drawing.Point(293, 87);
            this.cmbCustomer.Name = "cmbCustomer";
            this.cmbCustomer.Size = new System.Drawing.Size(263, 23);
            this.cmbCustomer.TabIndex = 3;
            // 
            // bdsCustomers
            // 
            this.bdsCustomers.DataSource = typeof(OrderManagement.Customer);
            // 
            // btnModify
            // 
            this.btnModify.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnModify.Location = new System.Drawing.Point(366, 316);
            this.btnModify.Name = "btnModify";
            this.btnModify.Size = new System.Drawing.Size(190, 31);
            this.btnModify.TabIndex = 4;
            this.btnModify.Text = "修改";
            this.btnModify.UseVisualStyleBackColor = true;
            this.btnModify.Click += new System.EventHandler(this.btnModify_Click);
            // 
            // lblChosenItem
            // 
            this.lblChosenItem.AutoSize = true;
            this.lblChosenItem.Location = new System.Drawing.Point(28, 153);
            this.lblChosenItem.Name = "lblChosenItem";
            this.lblChosenItem.Size = new System.Drawing.Size(157, 15);
            this.lblChosenItem.TabIndex = 5;
            this.lblChosenItem.Text = "选择要修改的订单项：";
            // 
            // bdsItems
            // 
            this.bdsItems.DataSource = typeof(OrderManagement.OrderItem);
            // 
            // cmbItem
            // 
            this.cmbItem.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbItem.DataSource = this.bdsItems;
            this.cmbItem.DisplayMember = "GoodsName";
            this.cmbItem.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbItem.FormattingEnabled = true;
            this.cmbItem.Location = new System.Drawing.Point(293, 145);
            this.cmbItem.Name = "cmbItem";
            this.cmbItem.Size = new System.Drawing.Size(263, 23);
            this.cmbItem.TabIndex = 6;
            this.cmbItem.SelectedIndexChanged += new System.EventHandler(this.cmbItem_SelectedIndexChanged);
            // 
            // lblModifyGoods
            // 
            this.lblModifyGoods.AutoSize = true;
            this.lblModifyGoods.Location = new System.Drawing.Point(28, 207);
            this.lblModifyGoods.Name = "lblModifyGoods";
            this.lblModifyGoods.Size = new System.Drawing.Size(172, 15);
            this.lblModifyGoods.TabIndex = 7;
            this.lblModifyGoods.Text = "将订单项的商品修改为：";
            // 
            // bdsGoods
            // 
            this.bdsGoods.DataSource = typeof(OrderManagement.Goods);
            // 
            // cmbGoods
            // 
            this.cmbGoods.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbGoods.DataSource = this.bdsGoods;
            this.cmbGoods.DisplayMember = "Name";
            this.cmbGoods.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGoods.FormattingEnabled = true;
            this.cmbGoods.Location = new System.Drawing.Point(293, 202);
            this.cmbGoods.Name = "cmbGoods";
            this.cmbGoods.Size = new System.Drawing.Size(263, 23);
            this.cmbGoods.TabIndex = 8;
            // 
            // lblModifyNum
            // 
            this.lblModifyNum.AutoSize = true;
            this.lblModifyNum.Location = new System.Drawing.Point(28, 261);
            this.lblModifyNum.Name = "lblModifyNum";
            this.lblModifyNum.Size = new System.Drawing.Size(142, 15);
            this.lblModifyNum.TabIndex = 9;
            this.lblModifyNum.Text = "将商品数量修改为：";
            // 
            // txtGoodsNum
            // 
            this.txtGoodsNum.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtGoodsNum.Location = new System.Drawing.Point(293, 255);
            this.txtGoodsNum.Name = "txtGoodsNum";
            this.txtGoodsNum.Size = new System.Drawing.Size(263, 25);
            this.txtGoodsNum.TabIndex = 10;
            // 
            // ModifyOrderDialogue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(601, 376);
            this.Controls.Add(this.txtGoodsNum);
            this.Controls.Add(this.lblModifyNum);
            this.Controls.Add(this.cmbGoods);
            this.Controls.Add(this.lblModifyGoods);
            this.Controls.Add(this.cmbItem);
            this.Controls.Add(this.lblChosenItem);
            this.Controls.Add(this.btnModify);
            this.Controls.Add(this.cmbCustomer);
            this.Controls.Add(this.lblModifyCustomer);
            this.Controls.Add(this.lblChosenOrder);
            this.Controls.Add(this.cmbChosenOrder);
            this.Name = "ModifyOrderDialogue";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "修改订单";
            this.Load += new System.EventHandler(this.ModifyOrderDialogue_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bdsOrders)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsCustomers)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsItems)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsGoods)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbChosenOrder;
        private System.Windows.Forms.BindingSource bdsOrders;
        private System.Windows.Forms.Label lblChosenOrder;
        private System.Windows.Forms.Label lblModifyCustomer;
        private System.Windows.Forms.ComboBox cmbCustomer;
        private System.Windows.Forms.BindingSource bdsCustomers;
        private System.Windows.Forms.Button btnModify;
        private System.Windows.Forms.Label lblChosenItem;
        private System.Windows.Forms.BindingSource bdsItems;
        private System.Windows.Forms.ComboBox cmbItem;
        private System.Windows.Forms.Label lblModifyGoods;
        private System.Windows.Forms.BindingSource bdsGoods;
        private System.Windows.Forms.ComboBox cmbGoods;
        private System.Windows.Forms.Label lblModifyNum;
        private System.Windows.Forms.TextBox txtGoodsNum;
    }
}