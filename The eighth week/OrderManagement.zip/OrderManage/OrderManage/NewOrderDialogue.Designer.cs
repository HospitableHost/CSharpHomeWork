﻿namespace OrderManage
{
    partial class NewOrderDialogue
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.gpbOrderInfo = new System.Windows.Forms.GroupBox();
            this.btnAddItem = new System.Windows.Forms.Button();
            this.txtGoodsNum = new System.Windows.Forms.TextBox();
            this.cmbCustomer = new System.Windows.Forms.ComboBox();
            this.bdsCustomer = new System.Windows.Forms.BindingSource(this.components);
            this.cmbGoods = new System.Windows.Forms.ComboBox();
            this.bdsGoods = new System.Windows.Forms.BindingSource(this.components);
            this.txtOrderId = new System.Windows.Forms.TextBox();
            this.lblGoodsNum = new System.Windows.Forms.Label();
            this.lblOrderCustomer = new System.Windows.Forms.Label();
            this.lblOrderGoods = new System.Windows.Forms.Label();
            this.lblOrderId = new System.Windows.Forms.Label();
            this.btnAddOrder = new System.Windows.Forms.Button();
            this.gpbOrderInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bdsCustomer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsGoods)).BeginInit();
            this.SuspendLayout();
            // 
            // gpbOrderInfo
            // 
            this.gpbOrderInfo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gpbOrderInfo.Controls.Add(this.btnAddItem);
            this.gpbOrderInfo.Controls.Add(this.txtGoodsNum);
            this.gpbOrderInfo.Controls.Add(this.cmbCustomer);
            this.gpbOrderInfo.Controls.Add(this.cmbGoods);
            this.gpbOrderInfo.Controls.Add(this.txtOrderId);
            this.gpbOrderInfo.Controls.Add(this.lblGoodsNum);
            this.gpbOrderInfo.Controls.Add(this.lblOrderCustomer);
            this.gpbOrderInfo.Controls.Add(this.lblOrderGoods);
            this.gpbOrderInfo.Controls.Add(this.lblOrderId);
            this.gpbOrderInfo.Location = new System.Drawing.Point(12, 21);
            this.gpbOrderInfo.Name = "gpbOrderInfo";
            this.gpbOrderInfo.Size = new System.Drawing.Size(873, 216);
            this.gpbOrderInfo.TabIndex = 0;
            this.gpbOrderInfo.TabStop = false;
            this.gpbOrderInfo.Text = "订单信息";
            // 
            // btnAddItem
            // 
            this.btnAddItem.Location = new System.Drawing.Point(673, 88);
            this.btnAddItem.Name = "btnAddItem";
            this.btnAddItem.Size = new System.Drawing.Size(112, 64);
            this.btnAddItem.TabIndex = 8;
            this.btnAddItem.Text = "向订单中添加一个订单项";
            this.btnAddItem.UseVisualStyleBackColor = true;
            this.btnAddItem.Click += new System.EventHandler(this.btnAddItem_Click);
            // 
            // txtGoodsNum
            // 
            this.txtGoodsNum.Location = new System.Drawing.Point(562, 110);
            this.txtGoodsNum.Name = "txtGoodsNum";
            this.txtGoodsNum.Size = new System.Drawing.Size(89, 25);
            this.txtGoodsNum.TabIndex = 7;
            // 
            // cmbCustomer
            // 
            this.cmbCustomer.DataSource = this.bdsCustomer;
            this.cmbCustomer.DisplayMember = "Name";
            this.cmbCustomer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbCustomer.FormattingEnabled = true;
            this.cmbCustomer.Location = new System.Drawing.Point(117, 161);
            this.cmbCustomer.Name = "cmbCustomer";
            this.cmbCustomer.Size = new System.Drawing.Size(262, 23);
            this.cmbCustomer.TabIndex = 6;
            // 
            // bdsCustomer
            // 
            this.bdsCustomer.DataSource = typeof(OrderManagement.Customer);
            // 
            // cmbGoods
            // 
            this.cmbGoods.DataSource = this.bdsGoods;
            this.cmbGoods.DisplayMember = "Name";
            this.cmbGoods.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbGoods.FormattingEnabled = true;
            this.cmbGoods.Location = new System.Drawing.Point(117, 108);
            this.cmbGoods.Name = "cmbGoods";
            this.cmbGoods.Size = new System.Drawing.Size(262, 23);
            this.cmbGoods.TabIndex = 5;
            // 
            // bdsGoods
            // 
            this.bdsGoods.DataSource = typeof(OrderManagement.Goods);
            // 
            // txtOrderId
            // 
            this.txtOrderId.Location = new System.Drawing.Point(117, 48);
            this.txtOrderId.Name = "txtOrderId";
            this.txtOrderId.Size = new System.Drawing.Size(262, 25);
            this.txtOrderId.TabIndex = 4;
            // 
            // lblGoodsNum
            // 
            this.lblGoodsNum.AutoSize = true;
            this.lblGoodsNum.Location = new System.Drawing.Point(474, 116);
            this.lblGoodsNum.Name = "lblGoodsNum";
            this.lblGoodsNum.Size = new System.Drawing.Size(67, 15);
            this.lblGoodsNum.TabIndex = 3;
            this.lblGoodsNum.Text = "商品数量";
            // 
            // lblOrderCustomer
            // 
            this.lblOrderCustomer.AutoSize = true;
            this.lblOrderCustomer.Location = new System.Drawing.Point(24, 166);
            this.lblOrderCustomer.Name = "lblOrderCustomer";
            this.lblOrderCustomer.Size = new System.Drawing.Size(67, 15);
            this.lblOrderCustomer.TabIndex = 2;
            this.lblOrderCustomer.Text = "订单顾客";
            // 
            // lblOrderGoods
            // 
            this.lblOrderGoods.AutoSize = true;
            this.lblOrderGoods.Location = new System.Drawing.Point(24, 113);
            this.lblOrderGoods.Name = "lblOrderGoods";
            this.lblOrderGoods.Size = new System.Drawing.Size(67, 15);
            this.lblOrderGoods.TabIndex = 1;
            this.lblOrderGoods.Text = "商品名称";
            // 
            // lblOrderId
            // 
            this.lblOrderId.AutoSize = true;
            this.lblOrderId.Location = new System.Drawing.Point(24, 55);
            this.lblOrderId.Name = "lblOrderId";
            this.lblOrderId.Size = new System.Drawing.Size(52, 15);
            this.lblOrderId.TabIndex = 0;
            this.lblOrderId.Text = "订单号";
            // 
            // btnAddOrder
            // 
            this.btnAddOrder.Location = new System.Drawing.Point(748, 254);
            this.btnAddOrder.Name = "btnAddOrder";
            this.btnAddOrder.Size = new System.Drawing.Size(137, 45);
            this.btnAddOrder.TabIndex = 1;
            this.btnAddOrder.Text = "添加订单";
            this.btnAddOrder.UseVisualStyleBackColor = true;
            this.btnAddOrder.Click += new System.EventHandler(this.btnAddOrder_Click);
            // 
            // NewOrderDialogue
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(897, 311);
            this.Controls.Add(this.btnAddOrder);
            this.Controls.Add(this.gpbOrderInfo);
            this.Name = "NewOrderDialogue";
            this.Text = "新增订单";
            this.gpbOrderInfo.ResumeLayout(false);
            this.gpbOrderInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bdsCustomer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsGoods)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gpbOrderInfo;
        private System.Windows.Forms.Label lblOrderId;
        private System.Windows.Forms.Label lblOrderCustomer;
        private System.Windows.Forms.Label lblOrderGoods;
        private System.Windows.Forms.Label lblGoodsNum;
        private System.Windows.Forms.Button btnAddItem;
        private System.Windows.Forms.TextBox txtGoodsNum;
        private System.Windows.Forms.ComboBox cmbCustomer;
        private System.Windows.Forms.BindingSource bdsCustomer;
        private System.Windows.Forms.ComboBox cmbGoods;
        private System.Windows.Forms.BindingSource bdsGoods;
        private System.Windows.Forms.TextBox txtOrderId;
        private System.Windows.Forms.Button btnAddOrder;
    }
}