﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OrderManagement;
namespace OrderManage
{
    public partial class NewOrderDialogue : Form
    {
        public event Action btnAddOrderClick;
        List<OrderItem> Orderitem = new List<OrderItem>();
        public NewOrderDialogue()
        {
            InitializeComponent();
            bdsCustomer.DataSource = CustomerManagement.customers;
            bdsGoods.DataSource = GoodsManagement.goods;
        }

        private void btnAddItem_Click(object sender, EventArgs e)
        {
            try
            {
                Goods goods = cmbGoods.SelectedItem as Goods;
                OrderItem item = new OrderItem(goods.Name, goods.Price, double.Parse(txtGoodsNum.Text));
                foreach(OrderItem i in Orderitem)
                {
                    if (item.Equals(i))
                        throw new OrderManagementException("订单项已存在", 11);
                }
                Orderitem.Add(item);
                new NewCustomerSuccess().ShowDialog();
            }
            catch(OrderManagementException)
            {
                new OrderItemExistErrorDialogue().ShowDialog();               
            }
            catch(ArgumentNullException)
            {
                new NumError().ShowDialog();
            }
            catch(FormatException)
            {
                new NumError().ShowDialog();
            }
            catch(OverflowException)
            {
                new NumError().ShowDialog();
            }
        }

        private void btnAddOrder_Click(object sender, EventArgs e)
        {
            try
            {
                Customer customer = cmbCustomer.SelectedItem as Customer;
                OrderService.AddOrder(int.Parse(txtOrderId.Text), Orderitem,customer );
                btnAddOrderClick();
                new NewCustomerSuccess().ShowDialog();
            }
            catch(OrderManagementException eee)
            {
                if (eee.Code == 1)
                    new OrderHasExisted().ShowDialog();
                else if (eee.Code == 3)
                    new CustomerNullError().ShowDialog();
                else
                    new OrderItemsEmptyError().ShowDialog();
            }
            catch (ArgumentNullException)
            {
                new OrderIdError().ShowDialog();
            }
            catch (FormatException)
            {
                new OrderIdError().ShowDialog();
            }
            catch (OverflowException)
            {
                new OrderIdError().ShowDialog();
            }
            finally
            {
                Orderitem = new List<OrderItem>();
            }

        }
    }
}
