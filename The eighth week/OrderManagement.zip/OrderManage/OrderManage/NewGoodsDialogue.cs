﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OrderManagement;
namespace OrderManage
{
    public partial class NewGoodsDialogue : Form
    {
        public NewGoodsDialogue()
        {
            InitializeComponent();
        }

        private void btnNewGoods_Click(object sender, EventArgs e)
        {
            try
            {
                Goods goods = new Goods(double.Parse(txtGoodsPrice.Text),txtGoodsName.Text);
                GoodsManagement.goods.Add(goods);
                NewCustomerSuccess newCustomerSuccess = new NewCustomerSuccess();
                newCustomerSuccess.ShowDialog();
            }
            catch
            {
                NewGoodsPriceError newGoodsPriceError = new NewGoodsPriceError();

                newGoodsPriceError.ShowDialog();
            }

        }
    }
}
