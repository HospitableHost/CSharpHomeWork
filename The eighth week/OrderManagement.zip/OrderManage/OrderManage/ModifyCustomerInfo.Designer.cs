﻿namespace OrderManage
{
    partial class ModifyCustomerInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnModifyCustomerInfo = new System.Windows.Forms.Button();
            this.cmbChooseCustomer = new System.Windows.Forms.ComboBox();
            this.bdsCustomers = new System.Windows.Forms.BindingSource(this.components);
            this.lblChosenCustomer = new System.Windows.Forms.Label();
            this.gbxCustomerInfo = new System.Windows.Forms.GroupBox();
            this.txtCustomerAddress = new System.Windows.Forms.TextBox();
            this.txtCustomerPhone = new System.Windows.Forms.TextBox();
            this.txtCustomerAge = new System.Windows.Forms.TextBox();
            this.txtCustomerGender = new System.Windows.Forms.TextBox();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.lblCustomerPhone = new System.Windows.Forms.Label();
            this.lblCustomerName = new System.Windows.Forms.Label();
            this.lblCustomerAddress = new System.Windows.Forms.Label();
            this.lblCustomerAge = new System.Windows.Forms.Label();
            this.lblCustomerGender = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.bdsCustomers)).BeginInit();
            this.gbxCustomerInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnModifyCustomerInfo
            // 
            this.btnModifyCustomerInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnModifyCustomerInfo.Location = new System.Drawing.Point(712, 17);
            this.btnModifyCustomerInfo.Name = "btnModifyCustomerInfo";
            this.btnModifyCustomerInfo.Size = new System.Drawing.Size(125, 30);
            this.btnModifyCustomerInfo.TabIndex = 0;
            this.btnModifyCustomerInfo.Text = "修改";
            this.btnModifyCustomerInfo.UseVisualStyleBackColor = true;
            this.btnModifyCustomerInfo.Click += new System.EventHandler(this.btnModifyCustomerInfo_Click);
            // 
            // cmbChooseCustomer
            // 
            this.cmbChooseCustomer.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbChooseCustomer.DataSource = this.bdsCustomers;
            this.cmbChooseCustomer.DisplayMember = "Name";
            this.cmbChooseCustomer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbChooseCustomer.FormattingEnabled = true;
            this.cmbChooseCustomer.Location = new System.Drawing.Point(232, 20);
            this.cmbChooseCustomer.Name = "cmbChooseCustomer";
            this.cmbChooseCustomer.Size = new System.Drawing.Size(453, 23);
            this.cmbChooseCustomer.TabIndex = 1;
            this.cmbChooseCustomer.SelectedIndexChanged += new System.EventHandler(this.cmbChooseCustomer_SelectedIndexChanged);
            // 
            // bdsCustomers
            // 
            this.bdsCustomers.DataSource = typeof(OrderManagement.Customer);
            // 
            // lblChosenCustomer
            // 
            this.lblChosenCustomer.AutoSize = true;
            this.lblChosenCustomer.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblChosenCustomer.Location = new System.Drawing.Point(12, 21);
            this.lblChosenCustomer.Name = "lblChosenCustomer";
            this.lblChosenCustomer.Size = new System.Drawing.Size(189, 20);
            this.lblChosenCustomer.TabIndex = 2;
            this.lblChosenCustomer.Text = "选择要修改的顾客：";
            // 
            // gbxCustomerInfo
            // 
            this.gbxCustomerInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.gbxCustomerInfo.Controls.Add(this.txtCustomerAddress);
            this.gbxCustomerInfo.Controls.Add(this.txtCustomerPhone);
            this.gbxCustomerInfo.Controls.Add(this.txtCustomerAge);
            this.gbxCustomerInfo.Controls.Add(this.txtCustomerGender);
            this.gbxCustomerInfo.Controls.Add(this.txtCustomerName);
            this.gbxCustomerInfo.Controls.Add(this.lblCustomerPhone);
            this.gbxCustomerInfo.Controls.Add(this.lblCustomerName);
            this.gbxCustomerInfo.Controls.Add(this.lblCustomerAddress);
            this.gbxCustomerInfo.Controls.Add(this.lblCustomerAge);
            this.gbxCustomerInfo.Controls.Add(this.lblCustomerGender);
            this.gbxCustomerInfo.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.gbxCustomerInfo.Location = new System.Drawing.Point(15, 70);
            this.gbxCustomerInfo.Name = "gbxCustomerInfo";
            this.gbxCustomerInfo.Size = new System.Drawing.Size(822, 349);
            this.gbxCustomerInfo.TabIndex = 3;
            this.gbxCustomerInfo.TabStop = false;
            this.gbxCustomerInfo.Text = "顾客信息";
            // 
            // txtCustomerAddress
            // 
            this.txtCustomerAddress.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCustomerAddress.Location = new System.Drawing.Point(116, 168);
            this.txtCustomerAddress.Name = "txtCustomerAddress";
            this.txtCustomerAddress.Size = new System.Drawing.Size(686, 30);
            this.txtCustomerAddress.TabIndex = 9;
            // 
            // txtCustomerPhone
            // 
            this.txtCustomerPhone.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCustomerPhone.Location = new System.Drawing.Point(116, 279);
            this.txtCustomerPhone.Name = "txtCustomerPhone";
            this.txtCustomerPhone.Size = new System.Drawing.Size(686, 30);
            this.txtCustomerPhone.TabIndex = 8;
            // 
            // txtCustomerAge
            // 
            this.txtCustomerAge.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCustomerAge.Location = new System.Drawing.Point(116, 225);
            this.txtCustomerAge.Name = "txtCustomerAge";
            this.txtCustomerAge.Size = new System.Drawing.Size(686, 30);
            this.txtCustomerAge.TabIndex = 7;
            // 
            // txtCustomerGender
            // 
            this.txtCustomerGender.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCustomerGender.Location = new System.Drawing.Point(116, 112);
            this.txtCustomerGender.Name = "txtCustomerGender";
            this.txtCustomerGender.Size = new System.Drawing.Size(686, 30);
            this.txtCustomerGender.TabIndex = 6;
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtCustomerName.Location = new System.Drawing.Point(116, 58);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(686, 30);
            this.txtCustomerName.TabIndex = 5;
            // 
            // lblCustomerPhone
            // 
            this.lblCustomerPhone.AutoSize = true;
            this.lblCustomerPhone.Location = new System.Drawing.Point(21, 284);
            this.lblCustomerPhone.Name = "lblCustomerPhone";
            this.lblCustomerPhone.Size = new System.Drawing.Size(89, 20);
            this.lblCustomerPhone.TabIndex = 4;
            this.lblCustomerPhone.Text = "顾客电话";
            // 
            // lblCustomerName
            // 
            this.lblCustomerName.AutoSize = true;
            this.lblCustomerName.Location = new System.Drawing.Point(21, 63);
            this.lblCustomerName.Name = "lblCustomerName";
            this.lblCustomerName.Size = new System.Drawing.Size(89, 20);
            this.lblCustomerName.TabIndex = 3;
            this.lblCustomerName.Text = "顾客姓名";
            // 
            // lblCustomerAddress
            // 
            this.lblCustomerAddress.AutoSize = true;
            this.lblCustomerAddress.Location = new System.Drawing.Point(21, 174);
            this.lblCustomerAddress.Name = "lblCustomerAddress";
            this.lblCustomerAddress.Size = new System.Drawing.Size(89, 20);
            this.lblCustomerAddress.TabIndex = 2;
            this.lblCustomerAddress.Text = "顾客地址";
            // 
            // lblCustomerAge
            // 
            this.lblCustomerAge.AutoSize = true;
            this.lblCustomerAge.Location = new System.Drawing.Point(21, 231);
            this.lblCustomerAge.Name = "lblCustomerAge";
            this.lblCustomerAge.Size = new System.Drawing.Size(89, 20);
            this.lblCustomerAge.TabIndex = 1;
            this.lblCustomerAge.Text = "顾客年龄";
            // 
            // lblCustomerGender
            // 
            this.lblCustomerGender.AutoSize = true;
            this.lblCustomerGender.Location = new System.Drawing.Point(21, 118);
            this.lblCustomerGender.Name = "lblCustomerGender";
            this.lblCustomerGender.Size = new System.Drawing.Size(89, 20);
            this.lblCustomerGender.TabIndex = 0;
            this.lblCustomerGender.Text = "顾客性别";
            // 
            // ModifyCustomerInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(849, 431);
            this.Controls.Add(this.gbxCustomerInfo);
            this.Controls.Add(this.lblChosenCustomer);
            this.Controls.Add(this.cmbChooseCustomer);
            this.Controls.Add(this.btnModifyCustomerInfo);
            this.Name = "ModifyCustomerInfo";
            this.Text = "修改顾客信息";
            ((System.ComponentModel.ISupportInitialize)(this.bdsCustomers)).EndInit();
            this.gbxCustomerInfo.ResumeLayout(false);
            this.gbxCustomerInfo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnModifyCustomerInfo;
        private System.Windows.Forms.ComboBox cmbChooseCustomer;
        private System.Windows.Forms.BindingSource bdsCustomers;
        private System.Windows.Forms.Label lblChosenCustomer;
        private System.Windows.Forms.GroupBox gbxCustomerInfo;
        private System.Windows.Forms.Label lblCustomerPhone;
        private System.Windows.Forms.Label lblCustomerName;
        private System.Windows.Forms.Label lblCustomerAddress;
        private System.Windows.Forms.Label lblCustomerAge;
        private System.Windows.Forms.Label lblCustomerGender;
        private System.Windows.Forms.TextBox txtCustomerAddress;
        private System.Windows.Forms.TextBox txtCustomerPhone;
        private System.Windows.Forms.TextBox txtCustomerAge;
        private System.Windows.Forms.TextBox txtCustomerGender;
        private System.Windows.Forms.TextBox txtCustomerName;
    }
}