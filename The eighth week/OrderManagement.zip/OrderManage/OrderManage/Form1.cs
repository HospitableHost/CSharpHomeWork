﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OrderManagement;
namespace OrderManage
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            bdsOrders.DataSource = OrderService.orders;   
        }
        private void FreshDgv()
        {
            bdsOrders.DataSource = OrderService.orders;
            bdsOrders.ResetBindings(false);
        }
        private void FreshDgvAfterQuery(List<Order> os)
        {
            if (os == null)
                os = new List<Order>();
            bdsOrders.DataSource = os;
            bdsOrders.ResetBindings(false);
        }

        private void 新建订单ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewOrderDialogue newOrderDialogue = new NewOrderDialogue();
            newOrderDialogue.btnAddOrderClick += FreshDgv;
            newOrderDialogue.ShowDialog();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void 新增顾客信息ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewCustomerDialog newCustomerDialog = new NewCustomerDialog();
            newCustomerDialog.ShowDialog();
        }

        private void 修改顾客信息ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ModifyCustomerInfo modifyCustomerInfo = new ModifyCustomerInfo();
            modifyCustomerInfo.ShowDialog();
        }

        private void 新增商品信息ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NewGoodsDialogue newGoodsDialogue = new NewGoodsDialogue();
            newGoodsDialogue.ShowDialog();
        }

        private void 修改商品ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ModifyGoodsInfo modifyGoodsInfo = new ModifyGoodsInfo();
            modifyGoodsInfo.ShowDialog();
        }

        private void 导入订单ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (odlgOrdersXML.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    OrderService.orders=OrderService.ImportFromXML(odlgOrdersXML.FileName);
                    bdsOrders.DataSource = OrderService.orders;
                    FreshDgv();
                    new ImportSuccess().ShowDialog();
                }
                catch
                {
                    new ImportOrdersNotXML().ShowDialog();
                }
            }
        }

        private void 导出订单ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(sdlgSaveOrders.ShowDialog()==DialogResult.OK)
            {
                OrderService.ExportToXML(sdlgSaveOrders.FileName);
            }
        }

        private void 修改订单ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ModifyOrderDialogue modifyOrderDialogue = new ModifyOrderDialogue();
            modifyOrderDialogue.ModifySuccess += FreshDgv;
            modifyOrderDialogue.ShowDialog();
        }

        private void 删除订单ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteOrderDialogue deleteOrderDialogue = new DeleteOrderDialogue();
            deleteOrderDialogue.deleteSuccess += FreshDgv;
            deleteOrderDialogue.ShowDialog();
        }

        private void 查询订单ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            QueryOrdersDialogue queryOrdersDialogue = new QueryOrdersDialogue();
            queryOrdersDialogue.Back += FreshDgv;
            queryOrdersDialogue.QuerySucess += FreshDgvAfterQuery;
            queryOrdersDialogue.Show();
        }

    }
}
