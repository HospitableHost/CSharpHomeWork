﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OrderManagement;

namespace OrderManage
{
    public partial class NewCustomerDialog : Form
    {
        public NewCustomerDialog()
        {
            InitializeComponent();
        }

        private void btnNewCustomer_Click(object sender, EventArgs e)
        {
            try
            {
                Customer customer = new Customer(txtCustomerName.Text, txtCustomerGender.Text, txtCustomerAddress.Text, int.Parse(txtCustomerAge.Text), txtCustomerPhone.Text);
                CustomerManagement.customers.Add(customer);
                NewCustomerSuccess newCustomerSuccess = new NewCustomerSuccess();
                newCustomerSuccess.ShowDialog();
            }
            catch
            {
                CustomerAgeErrorDialogue customerAgeErrorDialogue = new CustomerAgeErrorDialogue();
                customerAgeErrorDialogue.ShowDialog();
            }
        }
    }
}
