﻿namespace OrderManage
{
    partial class NewGoodsPriceError
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNewGoodsPriceError1 = new System.Windows.Forms.Label();
            this.lblNewGoodsPriceError2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblNewGoodsPriceError1
            // 
            this.lblNewGoodsPriceError1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblNewGoodsPriceError1.AutoSize = true;
            this.lblNewGoodsPriceError1.Font = new System.Drawing.Font("李旭科书法", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblNewGoodsPriceError1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblNewGoodsPriceError1.Location = new System.Drawing.Point(32, 41);
            this.lblNewGoodsPriceError1.Name = "lblNewGoodsPriceError1";
            this.lblNewGoodsPriceError1.Size = new System.Drawing.Size(276, 34);
            this.lblNewGoodsPriceError1.TabIndex = 0;
            this.lblNewGoodsPriceError1.Text = "商品价格非数值格式";
            // 
            // lblNewGoodsPriceError2
            // 
            this.lblNewGoodsPriceError2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblNewGoodsPriceError2.AutoSize = true;
            this.lblNewGoodsPriceError2.Font = new System.Drawing.Font("李旭科书法", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblNewGoodsPriceError2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblNewGoodsPriceError2.Location = new System.Drawing.Point(61, 97);
            this.lblNewGoodsPriceError2.Name = "lblNewGoodsPriceError2";
            this.lblNewGoodsPriceError2.Size = new System.Drawing.Size(218, 34);
            this.lblNewGoodsPriceError2.TabIndex = 1;
            this.lblNewGoodsPriceError2.Text = "添加或修改失败";
            // 
            // NewGoodsPriceError
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(331, 193);
            this.Controls.Add(this.lblNewGoodsPriceError2);
            this.Controls.Add(this.lblNewGoodsPriceError1);
            this.Name = "NewGoodsPriceError";
            this.Text = "警告";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNewGoodsPriceError1;
        private System.Windows.Forms.Label lblNewGoodsPriceError2;
    }
}